"""
Time Analysis Routes - Detailed breakdown of walking, picking, and packing times
"""

from flask import render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from app import app, db
from models import (Invoice, InvoiceItem, User, OrderTimeBreakdown, ItemTimeTracking, 
                   ActivityLog, PickingException)
from datetime import datetime, timedelta
import pytz

# Set timezone for consistent reporting
TIMEZONE = pytz.timezone('Europe/Athens')

@app.route('/admin/time_analysis')
@login_required
def time_analysis_dashboard():
    """Admin dashboard for detailed time analysis"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('index'))
    
    # Get date filters from request
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    picker_filter = request.args.get('picker', '')
    
    # Set default date range (last 7 days)
    if not start_date_str:
        start_date = datetime.now(TIMEZONE).replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=7)
    else:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').replace(tzinfo=TIMEZONE)
    
    if not end_date_str:
        end_date = datetime.now(TIMEZONE).replace(hour=23, minute=59, second=59, microsecond=999999)
    else:
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999, tzinfo=TIMEZONE)
    
    # Base query for completed orders in date range
    orders_query = Invoice.query.filter(
        Invoice.status == 'Completed',
        Invoice.packing_complete_time >= start_date,
        Invoice.packing_complete_time <= end_date
    )
    
    # Apply picker filter if specified
    if picker_filter:
        orders_query = orders_query.filter(Invoice.assigned_to == picker_filter)
    
    completed_orders = orders_query.order_by(Invoice.packing_complete_time.desc()).all()
    
    # Get all pickers for filter dropdown
    pickers = User.query.filter_by(role='picker').all()
    
    # Calculate detailed time breakdowns for each order
    order_analytics = []
    total_orders = len(completed_orders)
    total_walking_time = 0
    total_picking_time = 0
    total_packing_time = 0
    
    for invoice in completed_orders:
        # Get or create time breakdown record
        time_breakdown = OrderTimeBreakdown.query.filter_by(invoice_no=invoice.invoice_no).first()
        
        if not time_breakdown:
            # Create new breakdown record by analyzing activity logs
            time_breakdown = create_time_breakdown_from_activities(invoice)
        
        # Calculate metrics for this order
        order_data = {
            'invoice': invoice,
            'time_breakdown': time_breakdown,
            'total_items': InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).count(),
            'picked_items': InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no, is_picked=True).count(),
            'unique_locations': len(set(item.location for item in invoice.items if item.location)),
            'efficiency_score': calculate_efficiency_score(invoice, time_breakdown)
        }
        
        order_analytics.append(order_data)
        
        # Add to totals
        if time_breakdown:
            total_walking_time += time_breakdown.total_walking_time or 0
            total_picking_time += time_breakdown.total_picking_time or 0
            total_packing_time += time_breakdown.total_packing_time or 0
    
    # Calculate summary statistics
    summary_stats = {
        'total_orders': total_orders,
        'avg_walking_time': round(total_walking_time / max(total_orders, 1), 1),
        'avg_picking_time': round(total_picking_time / max(total_orders, 1), 1),
        'avg_packing_time': round(total_packing_time / max(total_orders, 1), 1),
        'total_time': total_walking_time + total_picking_time + total_packing_time,
        'walking_percentage': round((total_walking_time / max(total_walking_time + total_picking_time + total_packing_time, 1)) * 100, 1),
        'picking_percentage': round((total_picking_time / max(total_walking_time + total_picking_time + total_packing_time, 1)) * 100, 1),
        'packing_percentage': round((total_packing_time / max(total_walking_time + total_picking_time + total_packing_time, 1)) * 100, 1)
    }
    
    return render_template('time_analysis_dashboard.html',
                         order_analytics=order_analytics,
                         summary_stats=summary_stats,
                         pickers=pickers,
                         start_date=start_date,
                         end_date=end_date,
                         picker_filter=picker_filter)

@app.route('/admin/time_analysis/order/<invoice_no>')
@login_required
def detailed_order_analysis(invoice_no):
    """Detailed time analysis for a specific order"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    time_breakdown = OrderTimeBreakdown.query.filter_by(invoice_no=invoice_no).first()
    
    if not time_breakdown:
        time_breakdown = create_time_breakdown_from_activities(invoice)
    
    # Get item-level time tracking
    item_tracking = ItemTimeTracking.query.filter_by(invoice_no=invoice_no).all()
    
    # Get all activity logs for this invoice
    activity_logs = ActivityLog.query.filter_by(invoice_no=invoice_no).order_by(ActivityLog.timestamp).all()
    
    # Get all items with their picking details
    items = InvoiceItem.query.filter_by(invoice_no=invoice_no).all()
    
    # Calculate location-based metrics
    location_metrics = calculate_location_metrics(items, activity_logs)
    
    return render_template('detailed_order_analysis.html',
                         invoice=invoice,
                         time_breakdown=time_breakdown,
                         item_tracking=item_tracking,
                         activity_logs=activity_logs,
                         items=items,
                         location_metrics=location_metrics)

def create_time_breakdown_from_activities(invoice):
    """Create time breakdown record by analyzing activity logs"""
    try:
        # Get all picking activities for this invoice
        picking_activities = ActivityLog.query.filter_by(
            invoice_no=invoice.invoice_no,
            activity_type='item_pick'
        ).order_by(ActivityLog.timestamp).all()
        
        if not picking_activities:
            return None
        
        # Create time breakdown record
        time_breakdown = OrderTimeBreakdown(
            invoice_no=invoice.invoice_no,
            picker_username=invoice.assigned_to or 'unknown',
            picking_started=picking_activities[0].timestamp,
            picking_completed=picking_activities[-1].timestamp,
            packing_started=picking_activities[-1].timestamp,  # Assume packing starts after last pick
            packing_completed=invoice.packing_complete_time
        )
        
        # Count items and locations
        items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
        time_breakdown.total_items_picked = len([item for item in items if item.is_picked])
        time_breakdown.total_locations_visited = len(set(item.location for item in items if item.location))
        
        # Calculate time breakdowns
        time_breakdown.calculate_times()
        
        # Save to database
        db.session.add(time_breakdown)
        db.session.commit()
        
        return time_breakdown
        
    except Exception as e:
        print(f"Error creating time breakdown for {invoice.invoice_no}: {e}")
        return None

def calculate_efficiency_score(invoice, time_breakdown):
    """Calculate an efficiency score based on time vs expected time"""
    if not time_breakdown or not time_breakdown.total_picking_time:
        return None
    
    # Get expected time from items
    items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
    expected_time = sum(item.exp_time or 0 for item in items)
    
    if expected_time == 0:
        return None
    
    # Calculate efficiency (expected/actual * 100)
    actual_time = time_breakdown.total_picking_time + time_breakdown.total_walking_time
    efficiency = (expected_time / actual_time) * 100
    
    return round(efficiency, 1)

def calculate_location_metrics(items, activity_logs):
    """Calculate metrics by location"""
    location_data = {}
    
    for item in items:
        if not item.location:
            continue
            
        if item.location not in location_data:
            location_data[item.location] = {
                'items_count': 0,
                'total_quantity': 0,
                'zone': item.zone,
                'estimated_time': 0
            }
        
        location_data[item.location]['items_count'] += 1
        location_data[item.location]['total_quantity'] += item.qty or 0
        location_data[item.location]['estimated_time'] += item.exp_time or 0
    
    return location_data

@app.route('/admin/time_analysis/export')
@login_required
def export_time_analysis():
    """Export time analysis data as CSV"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('index'))
    
    # This would generate a CSV export of the time analysis data
    # Implementation would be similar to other export functions
    pass