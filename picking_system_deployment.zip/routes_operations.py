"""
Operational dashboard routes for the three-view workflow:
1. Open Orders - Warehouse operations
2. On Shipment - Logistics tracking  
3. Archive - Historical records
"""

from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import Invoice, User, ShipmentOrder, PickingException, InvoiceItem
from app import app, db
from datetime import datetime, timedelta


@app.route('/operations/open-orders')
@login_required
def open_orders():
    """Open Orders view - Warehouse operations"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get all invoices with warehouse statuses
    warehouse_statuses = ['not_started', 'picking', 'awaiting_batch_items', 'ready_for_dispatch', 'returned_to_warehouse']
    open_orders = Invoice.query.filter(Invoice.status.in_(warehouse_statuses)).all()
    
    # Get additional information for each order
    invoice_exceptions = {}
    picked_lines_count = {}
    total_lines_count = {}
    
    for invoice in open_orders:
        # Count exceptions
        exception_count = PickingException.query.filter_by(invoice_no=invoice.invoice_no).count()
        invoice_exceptions[invoice.invoice_no] = exception_count
        
        # Count lines
        items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
        total_lines_count[invoice.invoice_no] = len(items)
        picked_lines_count[invoice.invoice_no] = sum(1 for item in items if item.is_picked)
    
    # Get all pickers for assignment
    pickers = User.query.filter_by(role='picker').all()
    
    # Group orders by status for better organization
    orders_by_status = {
        'not_started': [o for o in open_orders if o.status == 'not_started'],
        'picking': [o for o in open_orders if o.status == 'picking'],
        'awaiting_batch_items': [o for o in open_orders if o.status == 'awaiting_batch_items'],
        'ready_for_dispatch': [o for o in open_orders if o.status == 'ready_for_dispatch'],
        'returned_to_warehouse': [o for o in open_orders if o.status == 'returned_to_warehouse']
    }
    
    return render_template('operations_open_orders.html',
                         orders_by_status=orders_by_status,
                         pickers=pickers,
                         invoice_exceptions=invoice_exceptions,
                         picked_lines_count=picked_lines_count,
                         total_lines_count=total_lines_count)


@app.route('/operations/shipments')
@login_required  
def on_shipment():
    """On Shipment view - Logistics tracking"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get all shipment orders
    shipment_statuses = ['shipped', 'delivery_failed']
    shipment_orders = Invoice.query.filter(Invoice.status.in_(shipment_statuses)).all()
    
    # Get shipment details
    from models import Shipment
    shipments_info = {}
    
    for invoice in shipment_orders:
        # Find the shipment this order belongs to
        shipment_order = ShipmentOrder.query.filter_by(invoice_no=invoice.invoice_no).first()
        if shipment_order:
            shipment = Shipment.query.get(shipment_order.shipment_id)
            if shipment:
                shipments_info[invoice.invoice_no] = {
                    'shipment_id': shipment.id,
                    'courier': shipment.driver_name,
                    'ship_date': shipment.delivery_date,
                    'tracking_number': getattr(shipment, 'tracking_number', 'N/A')
                }
    
    return render_template('operations_shipments.html',
                         shipment_orders=shipment_orders,
                         shipments_info=shipments_info)


@app.route('/operations/archive')
@login_required
def archive():
    """Archive view - Historical records"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get filter parameters
    status_filter = request.args.get('status', '')
    customer_filter = request.args.get('customer', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Base query for archived orders
    archive_statuses = ['delivered', 'cancelled']
    query = Invoice.query.filter(Invoice.status.in_(archive_statuses))
    
    # Apply filters
    if status_filter:
        query = query.filter(Invoice.status == status_filter)
    if customer_filter:
        query = query.filter(Invoice.customer_name.ilike(f'%{customer_filter}%'))
    if date_from:
        try:
            from_date = datetime.strptime(date_from, '%Y-%m-%d')
            # Using invoice_no for date filtering since created_at may not exist
            pass
        except ValueError:
            pass
    if date_to:
        try:
            to_date = datetime.strptime(date_to, '%Y-%m-%d')
            # Using invoice_no for date filtering since created_at may not exist
            pass
        except ValueError:
            pass
    
    # Order by most recent first
    archived_orders = query.order_by(Invoice.invoice_no.desc()).all()
    
    # Get unique customers for filter dropdown
    all_customers = db.session.query(Invoice.customer_name).filter(
        Invoice.status.in_(archive_statuses)
    ).distinct().all()
    customers = [c[0] for c in all_customers if c[0]]
    
    return render_template('operations_archive.html',
                         archived_orders=archived_orders,
                         customers=customers,
                         filters={
                             'status': status_filter,
                             'customer': customer_filter,
                             'date_from': date_from,
                             'date_to': date_to
                         })


@app.route('/operations/update-status', methods=['POST'])
@login_required
def update_order_status():
    """Update order status from operations views"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    invoice_no = request.form.get('invoice_no')
    new_status = request.form.get('new_status')
    
    if not invoice_no or not new_status:
        return jsonify({'success': False, 'message': 'Missing parameters'}), 400
    
    invoice = Invoice.query.filter_by(invoice_no=invoice_no).first()
    if not invoice:
        return jsonify({'success': False, 'message': 'Invoice not found'}), 404
    
    # Validate status transitions
    valid_statuses = ['not_started', 'picking', 'ready_for_dispatch', 'shipped', 
                     'delivered', 'delivery_failed', 'returned_to_warehouse', 'cancelled']
    
    if new_status not in valid_statuses:
        return jsonify({'success': False, 'message': 'Invalid status'}), 400
    
    # Update status
    old_status = invoice.status
    invoice.status = new_status
    invoice.status_updated_at = datetime.utcnow()
    
    try:
        db.session.commit()
        
        # Log the status change
        from models import ActivityLog
        activity = ActivityLog(
            invoice_no=invoice_no,
            activity_type='status_change',
            description=f'Status changed from {old_status} to {new_status}',
            username=current_user.username,
            timestamp=datetime.utcnow()
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({'success': True, 'message': f'Status updated to {new_status}'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500