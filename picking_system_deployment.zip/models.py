from datetime import datetime
from app import db
from flask_login import UserMixin
from sqlalchemy import and_
import pytz

def utc_now():
    """Return current UTC time for consistent database storage"""
    return datetime.utcnow()

# Settings Table
class Setting(db.Model):
    __tablename__ = 'settings'
    key = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.Text, nullable=False)
    
    @classmethod
    def get(cls, session, key, default="true"):
        """Get a setting value by key with an optional default"""
        setting = session.query(cls).filter_by(key=key).first()
        return setting.value if setting else default
    
    @classmethod
    def set(cls, session, key, value):
        """Set a setting value by key"""
        setting = session.query(cls).filter_by(key=key).first()
        if setting:
            setting.value = value
        else:
            setting = cls(key=key, value=value)
            session.add(setting)
        session.commit()
        
    @classmethod
    def get_json(cls, session, key, default=None):
        """Get a setting value as JSON"""
        import json
        if default is None:
            default = {}
        
        value = cls.get(session, key, json.dumps(default))
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return default
            
    @classmethod
    def set_json(cls, session, key, value):
        """Set a setting value as JSON"""
        import json
        json_value = json.dumps(value)
        return cls.set(session, key, json_value)

# User Model
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    username = db.Column(db.String(64), primary_key=True)
    password = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # 'admin' or 'picker'
    
    # Override get_id for Flask-Login
    def get_id(self):
        return self.username

# Invoices Table
class Invoice(db.Model):
    __tablename__ = 'invoices'
    invoice_no = db.Column(db.String(50), primary_key=True)
    routing = db.Column(db.String(100), nullable=True)
    customer_name = db.Column(db.String(200), nullable=True)
    upload_date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    assigned_to = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=True)
    total_lines = db.Column(db.Integer, default=0)
    total_items = db.Column(db.Integer, default=0)
    total_weight = db.Column(db.Float, default=0)
    total_exp_time = db.Column(db.Float, default=0)
    status = db.Column(db.String(20), default='not_started')  # not_started / picking / ready_for_dispatch / shipped / delivered
    status_updated_at = db.Column(db.DateTime, default=utc_now)  # When status was last changed
    current_item_index = db.Column(db.Integer, default=0)  # Track which item we're picking
    packing_complete_time = db.Column(db.DateTime, nullable=True)  # When packing was marked as complete
    picking_complete_time = db.Column(db.DateTime, nullable=True)  # When all items were picked (ready for packing stage)
    
    # Relationship with items
    items = db.relationship('InvoiceItem', backref='invoice', cascade='all, delete-orphan')
    # Relationship with assigned picker
    assigned_picker = db.relationship('User', backref='assigned_invoices')
    # Relationship with picking exceptions
    exceptions = db.relationship('PickingException', backref='invoice', cascade='all, delete-orphan')

# Invoice Items Table
class InvoiceItem(db.Model):
    __tablename__ = 'invoice_items'
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), primary_key=True)
    item_code = db.Column(db.String(50), primary_key=True)
    location = db.Column(db.String(100), nullable=True)
    corridor = db.Column(db.String(10), nullable=True)  # Corridor number with leading zeros (e.g., "09", "10")
    barcode = db.Column(db.String(100), nullable=True)
    zone = db.Column(db.String(50), nullable=True)
    item_weight = db.Column(db.Float, nullable=True)  # Items.Weight
    item_name = db.Column(db.String(200), nullable=True)
    unit_type = db.Column(db.String(50), nullable=True)
    pack = db.Column(db.String(50), nullable=True)
    qty = db.Column(db.Integer, nullable=True)
    line_weight = db.Column(db.Float, nullable=True)  # Items.Weight × QTY
    exp_time = db.Column(db.Float, nullable=True)
    picked_qty = db.Column(db.Integer, nullable=True)  # Actual picked quantity
    is_picked = db.Column(db.Boolean, default=False)  # Whether this item has been picked
    pick_status = db.Column(db.String(20), default='not_picked')  # not_picked, picked, reset, skipped, skipped_pending
    reset_by = db.Column(db.String(64), nullable=True)  # Username of admin who reset the item
    reset_timestamp = db.Column(db.DateTime, nullable=True)  # When the item was reset
    reset_note = db.Column(db.String(500), nullable=True)  # Optional note about reset reason
    # Skip functionality fields
    skip_reason = db.Column(db.Text, nullable=True)  # Reason provided when skipping an item
    skip_timestamp = db.Column(db.DateTime, nullable=True)  # When the item was skipped
    skip_count = db.Column(db.Integer, default=0)  # How many times the item was skipped
    
    # Batch locking system
    locked_by_batch_id = db.Column(db.Integer, nullable=True)  # If set, this item is locked by a batch
    
# Picking Exceptions Table
class PickingException(db.Model):
    __tablename__ = 'picking_exceptions'
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=False)
    item_code = db.Column(db.String(50), nullable=False)
    expected_qty = db.Column(db.Integer, nullable=False)
    picked_qty = db.Column(db.Integer, nullable=False)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    timestamp = db.Column(db.DateTime, default=utc_now)
    reason = db.Column(db.String(500), nullable=True)  # Optional reason for the exception
    
# Batch Picking Session Table
class BatchPickingSession(db.Model):
    __tablename__ = 'batch_picking_sessions'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    batch_number = db.Column(db.String(20), nullable=True, unique=True)  # Human-readable batch number (BATCH-YYYYMMDD-###)
    zones = db.Column(db.String(500), nullable=False)  # Comma-separated zones included in this batch
    corridors = db.Column(db.String(500), nullable=True)  # Comma-separated corridors included in this batch
    created_at = db.Column(db.DateTime, default=utc_now)
    created_by = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    assigned_to = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=True)
    status = db.Column(db.String(20), default='Created')  # Created / In Progress / Completed
    picking_mode = db.Column(db.String(20), nullable=False)  # Sequential / Consolidated
    current_invoice_index = db.Column(db.Integer, default=0)  # Track which invoice we're picking in Sequential mode
    current_item_index = db.Column(db.Integer, default=0)  # Track which item we're picking
    
    # Relationships
    creator = db.relationship('User', foreign_keys=[created_by], backref='created_batch_sessions')
    picker = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_batch_sessions')
    invoices = db.relationship('BatchSessionInvoice', backref='session', cascade='all, delete-orphan')
    
    def get_filtered_item_count(self):
        """Get the actual count of items that will be processed based on corridor filtering"""
        from sqlalchemy import and_, or_
        
        # Get all invoices in this batch
        batch_invoices = db.session.query(BatchSessionInvoice).filter_by(
            batch_session_id=self.id
        ).all()
        
        invoice_nos = [bi.invoice_no for bi in batch_invoices]
        zones_list = self.zones.split(',')
        corridors_list = self.corridors.split(',') if self.corridors else []
        
        if not invoice_nos or not zones_list:
            return 0
            
        # Build filter conditions for items that will actually be processed
        filter_conditions = [
            InvoiceItem.invoice_no.in_(invoice_nos),
            InvoiceItem.zone.in_(zones_list),
            InvoiceItem.is_picked == False,
            InvoiceItem.pick_status.in_(['not_picked', 'reset', 'skipped_pending'])
        ]
        
        # Add corridor filter if corridors are specified
        if corridors_list:
            filter_conditions.append(InvoiceItem.corridor.in_(corridors_list))
        
        # CRITICAL: Exclude items locked by OTHER active batches
        # Only count items that are either unlocked OR locked by THIS batch
        filter_conditions.append(
            or_(
                InvoiceItem.locked_by_batch_id.is_(None),
                InvoiceItem.locked_by_batch_id == self.id
            )
        )
        
        return db.session.query(InvoiceItem).filter(and_(*filter_conditions)).count()

    def get_grouped_items(self):
        """Get items grouped appropriately based on picking mode"""
        from sqlalchemy import and_
        
        # Get all invoices in this batch
        # Get invoice objects to properly iterate
        batch_invoices = db.session.query(BatchSessionInvoice).filter_by(
            batch_session_id=self.id
        ).all()
        
        # Get invoice numbers
        invoice_nos = [bi.invoice_no for bi in batch_invoices]
        
        # Build filter conditions for unpicked items in the selected zones and corridors
        zones_list = self.zones.split(',')
        corridors_list = self.corridors.split(',') if self.corridors else []
        
        if not invoice_nos or not zones_list:
            return []
            
        # Basic filter conditions for items - CRITICAL: Only include items locked by THIS batch
        filter_conditions = [
            InvoiceItem.invoice_no.in_(invoice_nos),
            InvoiceItem.zone.in_(zones_list),
            InvoiceItem.is_picked == False,
            InvoiceItem.pick_status.in_(['not_picked', 'reset', 'skipped_pending']),
            InvoiceItem.locked_by_batch_id == self.id  # CRUCIAL: Only items locked by this batch
        ]
        
        # Add corridor filter if corridors are specified
        if corridors_list:
            filter_conditions.append(InvoiceItem.corridor.in_(corridors_list))
        
        if self.picking_mode == 'Consolidated' or not self.picking_mode:
            # For consolidated mode, group identical items across orders
            # Store the full list of items that should be picked for debugging
            from flask import current_app
            all_batch_items = []
            
            # Get a list of all unpicked items across all invoices in this batch
            # Get this directly from the invoice_items table to see everything
            for invoice_no in invoice_nos:
                # Query all unpicked items in this invoice in the target zones and corridors
                item_filter_conditions = [
                    InvoiceItem.invoice_no == invoice_no,
                    InvoiceItem.zone.in_(zones_list),
                    InvoiceItem.is_picked == False,
                    InvoiceItem.pick_status.in_(['not_picked', 'reset', 'skipped_pending']),
                    InvoiceItem.locked_by_batch_id == self.id  # Only items locked by this batch
                ]
                
                # Add corridor filter if corridors are specified
                if corridors_list:
                    item_filter_conditions.append(InvoiceItem.corridor.in_(corridors_list))
                
                unpicked_by_invoice = db.session.query(
                    InvoiceItem
                ).filter(
                    and_(*item_filter_conditions)
                ).all()
                
                # Log the items found for each invoice
                current_app.logger.info(f"Invoice {invoice_no} has {len(unpicked_by_invoice)} items to be picked")
                for item in unpicked_by_invoice:
                    all_batch_items.append(item)
                    current_app.logger.info(f"  → Item: {item.item_code} (Zone: {item.zone}, Location: {item.location})")
            
            # Now process all found items, regardless of how they were filtered
            current_app.logger.info(f"Processing total of {len(all_batch_items)} items for consolidated picking")
            
            # Sort all items by zone, location, item_code for consistent order
            all_batch_items.sort(key=lambda x: (x.zone or "", x.location or "", x.item_code or ""))
            
            # Group items by a composite key to prevent collisions
            # Use invoice_no + item_code to ensure we capture all distinct items
            grouped_items = {}
            item_indexes = {}
            index_counter = 0
            
            # First pass: Create a catalog of all unique items
            for item in all_batch_items:
                # Get all items in their original form, then deduplicate
                full_item_key = f"{item.invoice_no}-{item.item_code}"
                if full_item_key not in item_indexes:
                    # Assign a stable index for this unique item
                    item_indexes[full_item_key] = index_counter
                    index_counter += 1
                
                # Create consolidated keys only for the batch view
                key = item.item_code
                if key not in grouped_items:
                    # Create a new consolidated item based on the first item
                    grouped_items[key] = {
                        'item_code': item.item_code,
                        'location': item.location,
                        'barcode': item.barcode,
                        'zone': item.zone,
                        'item_name': item.item_name,
                        'unit_type': item.unit_type,
                        'pack': item.pack,
                        'total_qty': 0,
                        'source_items': [],
                        'batch_index': len(grouped_items),  # Add index for stable grouping order
                        'original_indexes': []  # Track the original indexes for stable overall order
                    }
                
                # Add this item's quantity to the total and track the source
                grouped_items[key]['total_qty'] += item.qty
                grouped_items[key]['source_items'].append({
                    'invoice_no': item.invoice_no,
                    'item_code': item.item_code,
                    'qty': item.qty,
                    'id': item.invoice_no + '-' + item.item_code
                })
                
                # Store the original index to maintain stable sorting
                original_index = item_indexes[full_item_key]
                if original_index not in grouped_items[key]['original_indexes']:
                    grouped_items[key]['original_indexes'].append(original_index)
            
            # Additional verification: Use SQLAlchemy query directly to avoid SQL injection issues
            # This is more reliable than raw SQL with proper parameter handling
            from sqlalchemy import text
            
            # Use safer parameterized query with explicit text() declaration
            safe_sql = text("""
                SELECT DISTINCT item_code, invoice_no, zone, location 
                FROM invoice_items 
                WHERE invoice_no IN :invoice_nos
                AND zone IN :zones
                AND is_picked = false
                AND pick_status IN ('not_picked', 'reset', 'skipped_pending')
                AND locked_by_batch_id = :batch_id
                ORDER BY zone, location, item_code
            """)
            
            # Execute the query with properly bound parameters
            sql_result = db.session.execute(
                safe_sql, 
                {"invoice_nos": tuple(invoice_nos), "zones": tuple(zones_list), "batch_id": self.id}
            ).fetchall()
            if sql_result:
                # Get a set of item codes from SQL query for verification
                sql_item_codes = {row[0] for row in sql_result}
                sql_details = ", ".join(f"{row[0]} ({row[1]}, {row[2]})" for row in sql_result)
                current_app.logger.info(f"SQL query found {len(sql_item_codes)} unique item codes: {', '.join(sql_item_codes)}")
                
                # Check that all SQL-found items are included in our grouped items
                grouped_codes = set(grouped_items.keys())
                missing_from_group = sql_item_codes - grouped_codes
                
                if missing_from_group:
                    current_app.logger.warning(f"SQL found items missing from grouped results: {', '.join(missing_from_group)}")
                    # Add any missing items from the SQL query
                    for row in sql_result:
                        item_code = row[0]
                        if item_code in missing_from_group:
                            # Find this item in the original batch items
                            matching_items = [i for i in all_batch_items if i.item_code == item_code]
                            if matching_items:
                                item = matching_items[0]
                                # Add this item to grouped_items
                                grouped_items[item_code] = {
                                    'item_code': item.item_code,
                                    'location': item.location,
                                    'barcode': item.barcode,
                                    'zone': item.zone,
                                    'item_name': item.item_name,
                                    'unit_type': item.unit_type,
                                    'pack': item.pack,
                                    'total_qty': item.qty,
                                    'source_items': [{
                                        'invoice_no': item.invoice_no,
                                        'item_code': item.item_code,
                                        'qty': item.qty,
                                        'id': item.invoice_no + '-' + item.item_code
                                    }],
                                    'batch_index': len(grouped_items) + 100,  # Add at the end
                                    'original_indexes': [1000]  # High index to sort at end
                                }
                                current_app.logger.info(f"Recovered missing item: {item_code}")
            
            # Convert to a list of consolidated items
            result_items = list(grouped_items.values())
            
            # Sort items by location first, then by batch index as backup
            result_items.sort(key=lambda x: (
                x['zone'] or "",
                x['location'] or "",
                x['item_code'] or "",
                min(x['original_indexes']) if x['original_indexes'] else 999999
            ))
            
            # Log the final item list for debugging with clear sorting order
            current_app.logger.info(f"Returning {len(result_items)} consolidated items")
            for i, item in enumerate(result_items):
                current_app.logger.info(f"Item {i}: {item['item_code']} with qty {item['total_qty']} - zone: {item['zone']}, location: {item['location']}")
            
            # Debug which items are covered
            all_item_codes = [i.item_code for i in all_batch_items]
            unique_codes = set(all_item_codes)
            current_app.logger.info(f"Found {len(unique_codes)} unique item codes in original batch: {', '.join(unique_codes)}")
            
            result_codes = {i['item_code'] for i in result_items}
            current_app.logger.info(f"Returning {len(result_codes)} unique item codes: {', '.join(result_codes)}")
            
            # Check for any items that might be missing
            missing_codes = unique_codes - result_codes
            if missing_codes:
                current_app.logger.error(f"CRITICAL ERROR: Missing item codes in result: {', '.join(missing_codes)}")
            
            # Sanity check: Verify count matches database
            from sqlalchemy import func
            db_count = db.session.query(func.count(func.distinct(InvoiceItem.item_code))).filter(
                InvoiceItem.invoice_no.in_(invoice_nos),
                InvoiceItem.zone.in_(zones_list),
                InvoiceItem.is_picked == False,
                InvoiceItem.pick_status.in_(['not_picked', 'reset', 'skipped_pending']),
                InvoiceItem.locked_by_batch_id == self.id
            ).scalar()
            
            if db_count != len(result_items):
                current_app.logger.error(f"Count mismatch: Database shows {db_count} items but returning {len(result_items)}")
            
            return result_items
            
        else:  # 'Sequential' mode - Complete one order at a time
            from flask import current_app
            
            # Group all items by invoice for sequential processing
            items_by_invoice = {}
            all_items = InvoiceItem.query.filter(and_(*filter_conditions)).order_by(
                InvoiceItem.zone, 
                InvoiceItem.location,
                InvoiceItem.item_code
            ).all()
            
            # Group items by invoice
            for item in all_items:
                if item.invoice_no not in items_by_invoice:
                    items_by_invoice[item.invoice_no] = []
                items_by_invoice[item.invoice_no].append(item)
            
            # Get invoices with items, in order
            invoices_with_items = [inv for inv in invoice_nos if inv in items_by_invoice and items_by_invoice[inv]]
            
            if not invoices_with_items:
                current_app.logger.info("No invoices with items found")
                return []
            
            # First handle the case where current_invoice_index is out of bounds
            if self.current_invoice_index >= len(invoices_with_items):
                self.current_invoice_index = 0
            
            current_app.logger.info(f"Sequential mode: invoice_index={self.current_invoice_index}, invoices with items={invoices_with_items}")
            
            # Get the current invoice
            current_invoice = invoices_with_items[self.current_invoice_index]
            items = items_by_invoice[current_invoice]
            
            current_app.logger.info(f"Processing invoice {current_invoice} ({self.current_invoice_index + 1}/{len(invoices_with_items)}) with {len(items)} items")
            
            # Get order details for the current invoice
            invoice_details = Invoice.query.filter_by(invoice_no=current_invoice).first()
            
            # Create result items with order information for notifications
            result_items = []
            for item in items:
                result_items.append({
                    'item_code': item.item_code,
                    'item_name': item.item_name,
                    'location': item.location,
                    'zone': item.zone,
                    'barcode': item.barcode,
                    'unit_type': item.unit_type,
                    'pack': item.pack,
                    'total_qty': item.qty,
                    'current_invoice': current_invoice,  # Add current invoice info
                    'invoice_position': f"{self.current_invoice_index + 1}/{len(invoices_with_items)}",  # Add position info
                    'is_new_order': False,  # Will be set to True for first item of each order
                    # Add order details for notification
                    'customer_name': invoice_details.customer_name if invoice_details else None,
                    'order_total_items': invoice_details.total_items if invoice_details else None,
                    'order_total_weight': invoice_details.total_weight if invoice_details else None,
                    'source_items': [{
                        'invoice_no': item.invoice_no,
                        'item_code': item.item_code,
                        'qty': item.qty,
                        'id': item.invoice_no + '-' + item.item_code
                    }]
                })
            
            # Mark the first item as starting a new order
            if result_items:
                result_items[0]['is_new_order'] = True
                
            current_app.logger.info(f"Returning {len(result_items)} items for invoice {current_invoice}")
            return result_items

# Junction table to map multiple invoices to a batch picking session
class BatchSessionInvoice(db.Model):
    __tablename__ = 'batch_session_invoices'
    batch_session_id = db.Column(db.Integer, db.ForeignKey('batch_picking_sessions.id'), primary_key=True)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), primary_key=True)
    is_completed = db.Column(db.Boolean, default=False)
    
    # Allow retrieving the invoice directly
    invoice = db.relationship('Invoice')
    
# Track picked quantities for batch picking
class BatchPickedItem(db.Model):
    __tablename__ = 'batch_picked_items'
    id = db.Column(db.Integer, primary_key=True)
    batch_session_id = db.Column(db.Integer, db.ForeignKey('batch_picking_sessions.id'), nullable=False)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=False)
    item_code = db.Column(db.String(50), nullable=False)
    picked_qty = db.Column(db.Integer, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    
    # Relationships
    session = db.relationship('BatchPickingSession')
    invoice = db.relationship('Invoice')
    
# This class was already defined elsewhere in the file

# Picker Shift Tracking
class Shift(db.Model):
    __tablename__ = 'shifts'
    id = db.Column(db.Integer, primary_key=True)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    check_in_time = db.Column(db.DateTime, nullable=False, default=datetime.now)
    check_out_time = db.Column(db.DateTime, nullable=True)
    check_in_coordinates = db.Column(db.String(100), nullable=True)
    check_out_coordinates = db.Column(db.String(100), nullable=True)
    total_duration_minutes = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(20), default='active')  # active, completed, unclosed
    admin_adjusted = db.Column(db.Boolean, default=False)
    adjustment_note = db.Column(db.Text, nullable=True)
    adjustment_by = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=True)
    adjustment_time = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    picker = db.relationship('User', foreign_keys=[picker_username], backref='shifts')
    admin = db.relationship('User', foreign_keys=[adjustment_by], backref='shift_adjustments')
    idle_periods = db.relationship('IdlePeriod', backref='shift', cascade='all, delete-orphan')
    
    def calculate_duration(self):
        """Calculate the duration of the shift in minutes"""
        if self.check_in_time and self.check_out_time:
            delta = self.check_out_time - self.check_in_time
            return int(delta.total_seconds() / 60)
        return None
    
    def total_idle_time(self):
        """Calculate the total idle time in minutes for this shift"""
        idle_list = db.session.query(IdlePeriod).filter_by(shift_id=self.id).all()
        return sum(period.duration_minutes or 0 for period in idle_list)
    
    def break_count(self):
        """Count the number of manual breaks taken during this shift"""
        idle_list = db.session.query(IdlePeriod).filter_by(shift_id=self.id, is_break=True).all()
        return len(idle_list)

# Idle Periods and Breaks
class IdlePeriod(db.Model):
    __tablename__ = 'idle_periods'
    id = db.Column(db.Integer, primary_key=True)
    shift_id = db.Column(db.Integer, db.ForeignKey('shifts.id'), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False, default=datetime.now)
    end_time = db.Column(db.DateTime, nullable=True)
    duration_minutes = db.Column(db.Integer, nullable=True)
    is_break = db.Column(db.Boolean, default=False)
    break_reason = db.Column(db.String(200), nullable=True)
    
    def calculate_duration(self):
        """Calculate the duration of the idle period in minutes"""
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            return int(delta.total_seconds() / 60)
        return None

# Activity Logs for Tracking User Actions
class ActivityLog(db.Model):
    __tablename__ = 'activity_logs'
    id = db.Column(db.Integer, primary_key=True)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    activity_type = db.Column(db.String(50), nullable=True)  # e.g., 'item_pick', 'check_in', 'check_out', 'start_break', 'end_break', 'admin_action'
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=True)
    item_code = db.Column(db.String(50), nullable=True)
    details = db.Column(db.Text, nullable=True)
    
    # Relationships
    picker = db.relationship('User', backref='activities')

# Order Time Breakdown for detailed time analysis
class OrderTimeBreakdown(db.Model):
    __tablename__ = 'order_time_breakdown'
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=False)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    
    # Time tracking fields
    picking_started = db.Column(db.DateTime, nullable=True)  # When picking first item started
    picking_completed = db.Column(db.DateTime, nullable=True)  # When all items picked
    packing_started = db.Column(db.DateTime, nullable=True)  # When packing started
    packing_completed = db.Column(db.DateTime, nullable=True)  # When packing finished
    
    # Calculated time durations (in minutes)
    total_walking_time = db.Column(db.Float, default=0.0)  # Time spent walking between locations
    total_picking_time = db.Column(db.Float, default=0.0)  # Time spent actually picking items
    total_packing_time = db.Column(db.Float, default=0.0)  # Time spent packing
    
    # Additional metrics
    total_items_picked = db.Column(db.Integer, default=0)
    total_locations_visited = db.Column(db.Integer, default=0)
    average_time_per_item = db.Column(db.Float, default=0.0)  # Average time per item picked
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationships
    invoice = db.relationship('Invoice', backref='time_breakdown')
    picker = db.relationship('User', backref='order_time_breakdowns')
    
    def calculate_times(self):
        """Calculate various time metrics"""
        if self.picking_started and self.picking_completed:
            total_picking_duration = self.picking_completed - self.picking_started
            total_minutes = total_picking_duration.total_seconds() / 60
            
            # Estimate walking vs picking time based on locations and items
            if self.total_locations_visited > 0 and self.total_items_picked > 0:
                # Estimate 30 seconds walking time per location change
                estimated_walking = (self.total_locations_visited * 0.5)  # 0.5 minutes per location
                self.total_walking_time = min(estimated_walking, total_minutes * 0.4)  # Max 40% walking
                self.total_picking_time = total_minutes - self.total_walking_time
            else:
                # Fallback: assume 70% picking, 30% walking
                self.total_picking_time = total_minutes * 0.7
                self.total_walking_time = total_minutes * 0.3
        
        if self.packing_started and self.packing_completed:
            packing_duration = self.packing_completed - self.packing_started
            self.total_packing_time = packing_duration.total_seconds() / 60
        
        if self.total_items_picked > 0 and self.total_picking_time > 0:
            self.average_time_per_item = self.total_picking_time / self.total_items_picked

# Item-level time tracking for detailed analysis
class ItemTimeTracking(db.Model):
    __tablename__ = 'item_time_tracking'
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=False)
    item_code = db.Column(db.String(50), nullable=False)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    
    # Enhanced time tracking for AI analysis
    item_started = db.Column(db.DateTime, nullable=True)  # When picker started this item
    item_completed = db.Column(db.DateTime, nullable=True)  # When picker completed this item
    walking_time = db.Column(db.Float, default=0.0)  # Time to walk to location (seconds)
    picking_time = db.Column(db.Float, default=0.0)  # Time actually picking (seconds)
    confirmation_time = db.Column(db.Float, default=0.0)  # Time on confirmation screen (seconds)
    total_item_time = db.Column(db.Float, default=0.0)  # Total time for this item (seconds)
    
    # Location breakdown for AI analysis
    location = db.Column(db.String(100), nullable=True)
    zone = db.Column(db.String(50), nullable=True)
    corridor = db.Column(db.String(50), nullable=True)
    shelf = db.Column(db.String(50), nullable=True)
    level = db.Column(db.String(50), nullable=True)
    bin_location = db.Column(db.String(50), nullable=True)
    
    # Item characteristics for AI insights
    quantity_expected = db.Column(db.Integer, default=0)
    quantity_picked = db.Column(db.Integer, default=0)
    item_weight = db.Column(db.Float, nullable=True)
    item_name = db.Column(db.String(200), nullable=True)
    unit_type = db.Column(db.String(50), nullable=True)
    
    # Performance metrics for AI
    expected_time = db.Column(db.Float, default=0.0)  # Expected time from system
    efficiency_ratio = db.Column(db.Float, default=0.0)  # Actual vs expected ratio
    previous_location = db.Column(db.String(100), nullable=True)  # Previous pick location
    
    # Context for AI analysis
    order_sequence = db.Column(db.Integer, default=0)  # Position in picking order
    time_of_day = db.Column(db.String(10), nullable=True)  # morning/afternoon/evening
    day_of_week = db.Column(db.String(10), nullable=True)  # monday/tuesday/etc
    
    # Quality tracking for AI
    picked_correctly = db.Column(db.Boolean, default=True)
    was_skipped = db.Column(db.Boolean, default=False)
    skip_reason = db.Column(db.String(200), nullable=True)
    
    # Environmental context
    peak_hours = db.Column(db.Boolean, default=False)  # During busy periods
    concurrent_pickers = db.Column(db.Integer, default=1)  # Other active pickers
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationships
    invoice = db.relationship('Invoice')
    picker = db.relationship('User')
    
    def calculate_metrics(self):
        """Calculate efficiency and context metrics for AI analysis"""
        if self.item_started and self.item_completed:
            # Ensure both datetimes have timezone info or neither do
            import pytz
            athens_tz = pytz.timezone('Europe/Athens')
            
            # Convert both to timezone-aware if needed
            if self.item_started.tzinfo is None:
                item_started_tz = pytz.UTC.localize(self.item_started).astimezone(athens_tz)
            else:
                item_started_tz = self.item_started.astimezone(athens_tz)
                
            if self.item_completed.tzinfo is None:
                item_completed_tz = pytz.UTC.localize(self.item_completed).astimezone(athens_tz)
            else:
                item_completed_tz = self.item_completed.astimezone(athens_tz)
            
            delta = item_completed_tz - item_started_tz
            self.total_item_time = delta.total_seconds()
            
            # Calculate efficiency ratio
            if self.expected_time > 0:
                self.efficiency_ratio = self.total_item_time / self.expected_time
            
            # Set time of day context using timezone-aware datetime
            hour = item_started_tz.hour
            if 6 <= hour < 12:
                self.time_of_day = 'morning'
            elif 12 <= hour < 18:
                self.time_of_day = 'afternoon'
            else:
                self.time_of_day = 'evening'
            
            # Set day of week
            self.day_of_week = item_started_tz.strftime('%A').lower()
            
            # Determine if peak hours (8-10am, 1-3pm)
            self.peak_hours = (8 <= hour <= 10) or (13 <= hour <= 15)
    
    def to_ai_dict(self):
        """Convert to dictionary format for AI analysis"""
        return {
            'item_code': self.item_code,
            'location_data': {
                'zone': self.zone,
                'corridor': self.corridor,
                'shelf': self.shelf,
                'level': self.level,
                'bin': self.bin_location,
                'full_location': self.location,
                'previous_location': self.previous_location
            },
            'timing_data': {
                'walking_time': self.walking_time,
                'picking_time': self.picking_time,
                'confirmation_time': self.confirmation_time,
                'total_time': self.total_item_time,
                'expected_time': self.expected_time,
                'efficiency_ratio': self.efficiency_ratio
            },
            'item_data': {
                'weight': self.item_weight,
                'quantity_expected': self.quantity_expected,
                'quantity_picked': self.quantity_picked,
                'unit_type': self.unit_type,
                'name': self.item_name
            },
            'context_data': {
                'sequence': self.order_sequence,
                'time_of_day': self.time_of_day,
                'day_of_week': self.day_of_week,
                'picker': self.picker_username,
                'peak_hours': self.peak_hours,
                'concurrent_pickers': self.concurrent_pickers
            },
            'quality_data': {
                'picked_correctly': self.picked_correctly,
                'was_skipped': self.was_skipped,
                'skip_reason': self.skip_reason
            }
        }

# Time Tracking Alerts
class TimeTrackingAlert(db.Model):
    __tablename__ = 'time_tracking_alerts'
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), db.ForeignKey('invoices.invoice_no'), nullable=False)
    picker_username = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # 'warning', 'critical', 'exceeded'
    expected_duration = db.Column(db.Float, nullable=False)  # Expected time in minutes
    actual_duration = db.Column(db.Float, nullable=False)  # Actual time elapsed in minutes
    threshold_percentage = db.Column(db.Float, nullable=False)  # Percentage over expected (e.g. 150 = 50% over)
    created_at = db.Column(db.DateTime, default=datetime.now)
    is_resolved = db.Column(db.Boolean, default=False)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolved_by = db.Column(db.String(64), db.ForeignKey('users.username'), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    invoice = db.relationship('Invoice')
    picker = db.relationship('User', foreign_keys=[picker_username])
    resolver = db.relationship('User', foreign_keys=[resolved_by])


# Shipment Management Models
class Shipment(db.Model):
    __tablename__ = 'shipments'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_name = db.Column(db.String(100), nullable=False)
    route_name = db.Column(db.String(100))
    status = db.Column(db.String(20), nullable=False, default='created')  # created, in_transit, completed, cancelled
    delivery_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relationships
    shipment_orders = db.relationship('ShipmentOrder', backref='shipment', lazy=True, cascade='all, delete-orphan')


class ShipmentOrder(db.Model):
    __tablename__ = 'shipment_orders'
    
    id = db.Column(db.Integer, primary_key=True)
    shipment_id = db.Column(db.Integer, db.ForeignKey('shipments.id'), nullable=False)
    invoice_no = db.Column(db.String(20), db.ForeignKey('invoices.invoice_no'), nullable=False)
    
    # Relationships
    invoice = db.relationship('Invoice', backref='shipment_orders', lazy=True)
