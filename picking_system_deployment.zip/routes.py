import os
import logging
from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, session, jsonify, current_app
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

import json
import re
from sqlalchemy import func

from app import app, db
from models import User, Invoice, InvoiceItem, PickingException, Setting, Shift, IdlePeriod, ActivityLog, BatchPickingSession, BatchSessionInvoice
from utils import create_user
from utils.invoice_utils import recalculate_invoice_totals
from utils.shift_tracking import (
    check_in_picker, check_out_picker, start_break, end_break, 
    record_activity, check_for_idle_pickers, check_for_missed_checkouts,
    admin_adjust_shift, get_active_shift, get_picker_on_break
)
from image_handler import get_product_image
from import_handler import process_excel_file
from timezone_utils import get_local_time, format_local_time, localize_datetime


def sort_items_by_config(items):
    """
    Sort items based on the configured sorting options in the admin settings.
    Also prioritizes regular items over skipped_pending items.
    
    Args:
        items: List of InvoiceItem objects to sort
        
    Returns:
        Sorted list of InvoiceItem objects with skipped items at the end
    """
    # Default sorting configuration
    default_sorting = {
        "zone": {"enabled": True, "order": 1, "direction": "asc", "manual_priority": []},
        "corridor": {"enabled": True, "order": 2, "direction": "asc"},
        "shelf": {"enabled": True, "order": 3, "direction": "asc"},
        "level": {"enabled": True, "order": 4, "direction": "asc"},
        "bin": {"enabled": True, "order": 5, "direction": "asc"}
    }
    
    # Get sorting configuration from database
    try:
        import json
        setting = Setting.query.filter_by(key='picking_sort_config').first()
        if setting:
            sorting_config = json.loads(setting.value)
        else:
            sorting_config = default_sorting
    except Exception:
        sorting_config = default_sorting
        
    # Split the items into regular and skipped_pending
    regular_items = [item for item in items if item.pick_status != 'skipped_pending']
    skipped_items = [item for item in items if item.pick_status == 'skipped_pending']
    
    def extract_location_parts(location):
        """Extract different parts from a location string like '10-05-A03'"""
        if not location:
            return {'corridor': '', 'aisle': '', 'level': '', 'shelf': ''}
        
        parts = {}
        # Initialize default values
        parts['corridor'] = ''
        parts['aisle'] = ''
        parts['level'] = ''
        parts['shelf'] = ''
        
        # For warehouse location format: '10-05-A03'
        # First segment (10) = corridor, Second segment (05) = aisle, 
        # Last segment (A03) contains level (A) and shelf (03)
        if '-' in location:
            segments = location.split('-')
            
            # Handle corridor part (like '10' in '10-05-A03')
            if len(segments) >= 1:
                parts['corridor'] = segments[0]
                
            # Handle aisle part (like '05' in '10-05-A03')
            if len(segments) >= 2:
                parts['aisle'] = segments[1]
                
            # Handle level and shelf (ex: 'A03' in '10-05-A03')
            if len(segments) >= 3:
                last_segment = segments[2]
                
                # Separate level and shelf
                # Example: 'A03' -> level 'A' and shelf '03'
                import re
                match = re.match(r'([A-Za-z]*)(\d*)', last_segment)
                if match:
                    level_part, shelf_part = match.groups()
                    parts['level'] = level_part
                    parts['shelf'] = shelf_part
        else:
            # If no dashes, treat the entire location as corridor
            parts['corridor'] = location
            
        return parts
    
    def numeric_sort_key(value):
        """Create a sort key that properly handles numeric values within strings"""
        import re
        
        if not value:
            return ('', 0)  # Empty values sort first
            
        # Split the string into text and numeric parts
        parts = re.findall(r'(\d+|\D+)', value)
        
        # Convert numeric strings to integers for proper sorting
        result = []
        for part in parts:
            if part.isdigit():
                # Convert to integer for numeric comparison
                result.append(int(part))
            else:
                # Keep strings as strings
                result.append(part)
                
        # Convert result to a consistent format for comparison
        # Each element in the tuple must be comparable with elements of same index
        # in other tuples, so we need to ensure string-string and int-int comparisons
        final_result = []
        for i, item in enumerate(result):
            if isinstance(item, int):
                # All integers will be compared with integers
                final_result.append((1, item, ''))  # Type 1 = integer
            else:
                # All strings will be compared with strings
                final_result.append((0, 0, item))   # Type 0 = string
        
        return tuple(final_result)
    
    def get_sort_key(item):
        """Generate a sort key tuple based on configured sort order"""
        location = item.location or ''
        zone = item.zone or ''  # This is MAIN, SENSITIVE, SNACK from database
        
        # Extract location parts for corridor, aisle, level, shelf
        parts = extract_location_parts(location)
        corridor = parts['corridor'] or ''  # This is 10, 11, 12, 20, 30, etc.
        aisle = parts['aisle'] or ''
        level = parts['level'] or ''
        shelf = parts['shelf'] or ''
        
        # Create sort keys
        zone_key = numeric_sort_key(zone)
        corridor_key = numeric_sort_key(corridor)
        aisle_key = numeric_sort_key(aisle)
        level_key = numeric_sort_key(level)
        shelf_key = numeric_sort_key(shelf)
        location_key = numeric_sort_key(location)
        
        # Sort key generation complete
        
        # Check for manual zone priority (MAIN, SENSITIVE, SNACK)
        manual_zones = sorting_config.get('zone', {}).get('manual_priority', [])
        if manual_zones and zone:
            try:
                if zone in manual_zones:
                    zone_priority = manual_zones.index(zone)
                else:
                    zone_priority = len(manual_zones)
                # Sort by zone priority, then corridor, then aisle (shelf), then level, then bin (shelf)
                return (zone_priority, corridor_key, aisle_key, level_key, shelf_key)
            except (ValueError, TypeError, IndexError):
                pass
        
        # Default: sort by zone, then corridor, then aisle (shelf), then level, then bin (shelf)
        return (zone_key, corridor_key, aisle_key, level_key, shelf_key)
    
    # Sort each group (regular items and skipped items) separately
    try:
        # Sort regular items by location
        sorted_regular_items = sorted(regular_items, key=get_sort_key)
        
        # Sort skipped items by location
        sorted_skipped_items = sorted(skipped_items, key=get_sort_key)
        
        # Return regular items first, then skipped items
        return sorted_regular_items + sorted_skipped_items
    except Exception as e:
        app.logger.error(f"Error sorting items: {str(e)}")
        # Fall back to unsorted items but still keep regular items first
        return regular_items + skipped_items


# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # type: ignore

# Add context processor to provide the 'now' datetime to all templates
@app.context_processor
def inject_now():
    return {'now': get_local_time()}

# Template filter for timezone conversion
@app.template_filter('local_time')
def local_time_filter(dt):
    """Convert datetime to local timezone"""
    if dt is None:
        return ''
    return format_local_time(dt, '%Y-%m-%d %H:%M:%S')

@login_manager.user_loader
def load_user(username):
    return User.query.get(username)

# Login routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('picker_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('picker_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash('Login successful!', 'success')
            
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('picker_dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Allow users to change their own password"""
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate inputs
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required.', 'danger')
            return render_template('change_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match.', 'danger')
            return render_template('change_password.html')
        
        if len(new_password) < 4:
            flash('Password must be at least 4 characters long.', 'danger')
            return render_template('change_password.html')
        
        # Verify current password
        user = User.query.get(current_user.username)
        if not user or not check_password_hash(user.password, current_password):
            flash('Current password is incorrect.', 'danger')
            return render_template('change_password.html')
        
        # Update password
        user.password = generate_password_hash(new_password)
        db.session.commit()
        
        flash('Password changed successfully!', 'success')
        return redirect(url_for('picker_dashboard' if current_user.role == 'picker' else 'admin_dashboard'))
    
    return render_template('change_password.html')

@app.route('/admin/reset-password', methods=['GET', 'POST'])
@login_required
def admin_reset_password():
    """Allow admins to reset any user's password"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        target_username = request.form.get('target_username')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate inputs
        if not target_username or not new_password or not confirm_password:
            flash('All fields are required.', 'danger')
            return render_template('admin_reset_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match.', 'danger')
            return render_template('admin_reset_password.html')
        
        if len(new_password) < 4:
            flash('Password must be at least 4 characters long.', 'danger')
            return render_template('admin_reset_password.html')
        
        # Find target user
        target_user = User.query.get(target_username)
        if not target_user:
            flash('User not found.', 'danger')
            return render_template('admin_reset_password.html')
        
        # Update password
        target_user.password = generate_password_hash(new_password)
        db.session.commit()
        
        # Log the activity
        activity = ActivityLog()
        activity.picker_username = current_user.username
        activity.activity_type = "admin_action"
        activity.timestamp = get_local_time()
        activity.details = f"Admin {current_user.username} reset password for {target_username}"
        db.session.add(activity)
        db.session.commit()
        
        flash(f'Password for {target_username} has been reset successfully!', 'success')
        return redirect(url_for('admin_reset_password'))
    
    # Get all users for the dropdown
    users = User.query.all()
    # Check if a specific user was selected from the Users page
    selected_user = request.args.get('user')
    return render_template('admin_reset_password.html', users=users, selected_user=selected_user)

# Admin routes
@app.route('/admin')
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get sorting parameters
    sort_by = request.args.get('sort', 'status')
    sort_dir = request.args.get('dir', 'asc')
    
    # Filter for open warehouse orders only (Not Started, Picking, Awaiting Batch Items, Ready for Dispatch, Returned to Warehouse)
    open_warehouse_statuses = ['not_started', 'picking', 'awaiting_batch_items', 'ready_for_dispatch', 'returned_to_warehouse']
    all_invoices = Invoice.query.filter(Invoice.status.in_(open_warehouse_statuses)).all()
    
    # Get invoices that are assigned to shipments
    from models import ShipmentOrder
    assigned_invoice_numbers = db.session.query(ShipmentOrder.invoice_no).distinct().all()
    assigned_invoice_numbers = [inv[0] for inv in assigned_invoice_numbers]
    
    # Separate warehouse orders (not assigned to shipments) from shipped orders
    warehouse_invoices = [inv for inv in all_invoices if inv.invoice_no not in assigned_invoice_numbers]
    shipped_invoices = [inv for inv in all_invoices if inv.invoice_no in assigned_invoice_numbers]
    
    # Apply multi-level sorting to warehouse invoices (primary by status, secondary by routing)
    if warehouse_invoices:
        # Define proper status sequence for sorting
        status_order = {
            'not_started': 0,
            'picking': 1,
            'awaiting_batch_items': 2,
            'ready_for_dispatch': 3,
            'shipped': 4,
            'delivered': 5,
            'delivery_failed': 5,
            'returned_to_warehouse': 6,
            'cancelled': 7
        }
        
        def multi_sort_key(invoice):
            # Primary sort: status
            status_priority = status_order.get(invoice.status, 999)
            
            # Secondary sort: routing number (as numeric, with empty values last)
            routing = invoice.routing
            if not routing or routing.strip() == '':
                routing_priority = (1, 999999)  # Empty values last
            else:
                try:
                    # Try to convert to number for proper numeric sorting
                    routing_num = float(routing.strip())
                    routing_priority = (0, routing_num)
                except (ValueError, TypeError):
                    # If not a number, sort as string but after numbers
                    routing_priority = (0.5, routing.strip())
            
            return (status_priority, routing_priority)
        
        warehouse_invoices = sorted(warehouse_invoices, key=multi_sort_key)
    
    # Sort shipped invoices by invoice number (most recent first)
    shipped_invoices = sorted(shipped_invoices, key=lambda x: x.invoice_no or '', reverse=True)
    
    # For backward compatibility, keep 'invoices' as the main warehouse list
    invoices = warehouse_invoices
    
    # Filter completed invoices from warehouse orders only
    completed_invoices = [invoice for invoice in warehouse_invoices if invoice.status == 'Completed']
    
    # Get all pickers
    pickers = User.query.filter_by(role='picker').all()
    
    # Create dictionaries to store additional information
    invoice_exceptions = {}     # Store exception counts
    batch_picked_info = {}      # Store batch picking information 
    picked_lines_count = {}     # Store count of picked lines
    total_lines_count = {}      # Store count of total lines
    picking_times = {}          # Store total picking time for completed orders
    
    # Import BatchPickedItem model to check for batch-picked items
    from models import BatchPickedItem, BatchPickingSession
    
    for invoice in invoices:
        # Count exceptions for this invoice
        exception_count = PickingException.query.filter_by(invoice_no=invoice.invoice_no).count()
        invoice_exceptions[invoice.invoice_no] = exception_count
        
        # Count total lines and picked lines
        items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
        total_lines_count[invoice.invoice_no] = len(items)
        picked_lines_count[invoice.invoice_no] = sum(1 for item in items if item.is_picked)
        
        # Calculate total picking time for orders with completion timestamps
        if (invoice.packing_complete_time or invoice.picking_complete_time):
            # Use the actual completion timestamp from invoice records
            from models import ItemTimeTracking
            
            # Get the earliest item start time for this order
            earliest_start = db.session.query(func.min(ItemTimeTracking.item_started))\
                .filter(ItemTimeTracking.invoice_no == invoice.invoice_no)\
                .scalar()
            
            completion_time = invoice.packing_complete_time or invoice.picking_complete_time
            
            if earliest_start and completion_time:
                # Calculate actual time from start to completion
                picking_duration = completion_time - earliest_start
                total_seconds = picking_duration.total_seconds()
                total_minutes = total_seconds / 60
                
                if total_minutes >= 60:
                    hours = int(total_minutes // 60)
                    minutes = int(total_minutes % 60)
                    picking_times[invoice.invoice_no] = f"{hours}h {minutes}m"
                elif total_minutes >= 1:
                    picking_times[invoice.invoice_no] = f"{int(total_minutes)}min"
                else:
                    # Show seconds for very fast completions
                    picking_times[invoice.invoice_no] = f"{int(total_seconds)}sec"
            else:
                # Fallback to activity log method if no item tracking data
                from models import ActivityLog
                first_pick = ActivityLog.query.filter_by(
                    invoice_no=invoice.invoice_no,
                    activity_type='picking_started'
                ).order_by(ActivityLog.timestamp.asc()).first()
                
                if not first_pick:
                    first_pick = ActivityLog.query.filter_by(
                        invoice_no=invoice.invoice_no,
                        activity_type='item_pick'
                    ).order_by(ActivityLog.timestamp.asc()).first()
                
                if first_pick:
                    picking_duration = completion_time - first_pick.timestamp
                    total_seconds = picking_duration.total_seconds()
                    total_minutes = total_seconds / 60
                    
                    if total_minutes >= 60:
                        hours = int(total_minutes // 60)
                        minutes = int(total_minutes % 60)
                        picking_times[invoice.invoice_no] = f"{hours}h {minutes}m"
                    elif total_minutes >= 1:
                        picking_times[invoice.invoice_no] = f"{int(total_minutes)}min"
                    else:
                        picking_times[invoice.invoice_no] = f"{int(total_seconds)}sec"
                else:
                    picking_times[invoice.invoice_no] = "No timing data"
        
        # Check if any items were picked via batch
        batch_items = BatchPickedItem.query.filter_by(invoice_no=invoice.invoice_no).all()
        
        if batch_items:
            # Group by batch session for display
            batch_sessions = {}
            for batch_item in batch_items:
                batch_id = batch_item.batch_session_id
                if batch_id not in batch_sessions:
                    # Get the batch session name
                    batch = BatchPickingSession.query.get(batch_id)
                    batch_name = batch.name if batch else f"Batch #{batch_id}"
                    batch_number = batch.batch_number if batch and batch.batch_number else f"BATCH-{batch_id}"
                    batch_sessions[batch_id] = {
                        "id": batch_id,
                        "name": batch_name,
                        "batch_number": batch_number,
                        "count": 0,
                        "items": []
                    }
                
                batch_sessions[batch_id]["count"] += 1
                # Track the item code too
                item = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no, item_code=batch_item.item_code).first()
                if item:
                    batch_sessions[batch_id]["items"].append({
                        "code": item.item_code,
                        "name": item.item_name,
                        "qty": batch_item.picked_qty
                    })
            
            batch_picked_info[invoice.invoice_no] = batch_sessions
    
    # Calculate total remaining time for all warehouse orders
    total_remaining_time = 0
    for invoice in invoices:
        if invoice.status == 'not_started':
            # Add full expected time for not started orders
            total_remaining_time += (invoice.total_exp_time or 0)
        elif invoice.status == 'picking':
            # Add partial time for orders in progress
            picked_items = picked_lines_count.get(invoice.invoice_no, 0)
            total_items = total_lines_count.get(invoice.invoice_no, invoice.total_lines)
            if total_items > 0:
                remaining_percentage = ((total_items - picked_items) / total_items)
                remaining_time = (invoice.total_exp_time or 0) * remaining_percentage
                total_remaining_time += remaining_time
    
    return render_template('admin_dashboard.html', 
                          invoices=invoices, 
                          completed_invoices=completed_invoices,
                          shipped_invoices=shipped_invoices,
                          pickers=pickers,
                          invoice_exceptions=invoice_exceptions,
                          batch_picked_info=batch_picked_info,
                          picked_lines_count=picked_lines_count,
                          total_lines_count=total_lines_count,
                          picking_times=picking_times,
                          current_time=get_local_time(),
                          total_remaining_time=total_remaining_time,
                          sort_by=sort_by,
                          sort_dir=sort_dir)

@app.route('/admin/clear_data', methods=['GET', 'POST'])
@login_required
def clear_data():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    try:
        # Import batch models here to avoid circular imports
        from models import BatchPickedItem, BatchSessionInvoice, BatchPickingSession
        
        # Delete data in the correct order to respect foreign key constraints
        
        # First, delete batch picking data
        app.logger.info("Clearing batch picking records...")
        db.session.query(BatchPickedItem).delete()
        db.session.query(BatchSessionInvoice).delete()
        db.session.query(BatchPickingSession).delete()
        
        # Delete activity logs referencing invoices
        app.logger.info("Clearing relevant activity logs...")
        db.session.query(ActivityLog).filter(ActivityLog.invoice_no.isnot(None)).delete()
        
        # Delete picking exceptions
        app.logger.info("Clearing picking exceptions...")
        db.session.query(PickingException).delete()
        
        # Delete item time tracking records
        app.logger.info("Clearing item time tracking...")
        from models import ItemTimeTracking
        db.session.query(ItemTimeTracking).delete()
        
        # Delete time tracking alerts that reference invoices
        app.logger.info("Clearing time tracking alerts...")
        from models import TimeTrackingAlert
        db.session.query(TimeTrackingAlert).delete()
        
        # Delete shipment-related data
        app.logger.info("Clearing shipment orders...")
        from models import ShipmentOrder, Shipment
        db.session.query(ShipmentOrder).delete()
        
        app.logger.info("Clearing shipments...")
        db.session.query(Shipment).delete()
        
        # Delete invoice items
        app.logger.info("Clearing invoice items...")
        db.session.query(InvoiceItem).delete()
        
        # Finally delete invoices
        app.logger.info("Clearing invoices...")
        db.session.query(Invoice).delete()
        
        db.session.commit()
        flash('All invoice data has been cleared successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error clearing data: {str(e)}")
        flash(f'Error clearing data: {str(e)}', 'danger')
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/import', methods=['GET', 'POST'])
@login_required
def import_excel():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        # File upload handling
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        if not file or file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        
        if file and file.filename and file.filename.endswith('.xlsx'):
            try:
                # Create a temporary filename with timestamp to avoid conflicts
                import time
                timestamp = int(time.time())
                filename = f"import_{timestamp}_{secure_filename(str(file.filename))}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                # Make sure the upload folder exists
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                
                # Save the file
                file.save(filepath)
                logging.info(f"File saved to {filepath}")
                
                # Process the file with try/except block
                try:
                    # Process the Excel file with corridor extraction
                    success, message = process_excel_file(filepath, db.session)
                    
                    if success:
                        flash(f'File imported successfully: {message}', 'success')
                    else:
                        flash(f'Error importing file: {message}', 'danger')
                except Exception as e:
                    logging.error(f"Error processing file: {str(e)}")
                    flash(f'Error processing file: {str(e)}', 'danger')
                
                # Keep the file for reference
                # This helps avoid issues when importing large files
                logging.info(f"Keeping imported file at {filepath} for reference")
                    
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"File upload error: {str(e)}")
                flash(f'Error uploading file: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('Invalid file format. Please upload an Excel file (.xlsx)', 'danger')
            
    return render_template('import_excel.html')

@app.route('/admin/assign', methods=['POST'])
@login_required
def assign_picker():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice_no = request.form.get('invoice_no')
    picker_username = request.form.get('picker_username')
    
    if not invoice_no or not picker_username:
        flash('Missing required information', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    invoice = Invoice.query.get(invoice_no)
    if not invoice:
        flash(f'Invoice {invoice_no} not found', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    picker = User.query.filter_by(username=picker_username, role='picker').first()
    if not picker:
        flash(f'Picker {picker_username} not found', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    invoice.assigned_to = picker.username
    db.session.commit()
    
    flash(f'Invoice {invoice_no} assigned to {picker_username}', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/unassign', methods=['POST'])
@login_required
def unassign_picker():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice_no = request.form.get('invoice_no')
    
    if not invoice_no:
        flash('Missing required information', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    invoice = Invoice.query.get(invoice_no)
    if not invoice:
        flash(f'Invoice {invoice_no} not found', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    invoice.assigned_to = None
    db.session.commit()
    
    flash(f'Invoice {invoice_no} unassigned', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/users', methods=['GET', 'POST'])
@login_required
def manage_users():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        
        if not username or not password or not role:
            flash('All fields are required', 'danger')
            return redirect(url_for('manage_users'))
        
        success, message = create_user(db.session, username, password, role)
        
        if success:
            flash(f'User {username} created successfully', 'success')
        else:
            flash(message, 'danger')
            
        return redirect(url_for('manage_users'))
    
    users = User.query.all()
    return render_template('users.html', users=users)

@app.route('/admin/sorting', methods=['GET', 'POST'])
@login_required
def admin_sorting_settings():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Default sorting configuration
    default_sorting = {
        "zone": {"enabled": True, "order": 1, "direction": "asc", "manual_priority": []},
        "corridor": {"enabled": True, "order": 2, "direction": "asc"},
        "shelf": {"enabled": True, "order": 3, "direction": "asc"},
        "level": {"enabled": True, "order": 4, "direction": "asc"},
        "bin": {"enabled": True, "order": 5, "direction": "asc"}
    }
    
    if request.method == 'POST':
        # Build the new sorting configuration from form data
        new_sorting = {}
        
        # Get all sort parameters
        for field in ['zone', 'corridor', 'shelf', 'level', 'bin']:
            enabled = request.form.get(f'{field}_enabled') == 'on'
            order = int(request.form.get(f'{field}_order', 0))
            direction = request.form.get(f'{field}_direction', 'asc')
            
            new_sorting[field] = {
                "enabled": enabled,
                "order": order,
                "direction": direction
            }
            
            # Special handling for zone manual priority
            if field == 'zone':
                manual_priority = request.form.get('zone_manual_priority', '')
                manual_priority_list = [p.strip() for p in manual_priority.split(',') if p.strip()]
                new_sorting[field]['manual_priority'] = manual_priority_list
        
        # Save the configuration to the database
        try:
            import json
            setting = Setting.query.filter_by(key='picking_sort_config').first()
            if setting:
                setting.value = json.dumps(new_sorting)
            else:
                setting = Setting()
                setting.key = 'picking_sort_config'
                setting.value = json.dumps(new_sorting)
                db.session.add(setting)
            db.session.commit()
            flash('Sorting settings updated successfully', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error saving sorting settings: {str(e)}', 'danger')
        
        return redirect(url_for('admin_sorting_settings'))
    
    # Get current sorting configuration
    try:
        import json
        setting = Setting.query.filter_by(key='picking_sort_config').first()
        if setting:
            sorting_config = json.loads(setting.value)
        else:
            sorting_config = default_sorting
    except Exception:
        sorting_config = default_sorting
    
    # Convert manual priority list to comma-separated string for display
    if 'zone' in sorting_config and 'manual_priority' in sorting_config['zone']:
        manual_priority_str = ', '.join(sorting_config['zone']['manual_priority'])
    else:
        manual_priority_str = ''
    
    return render_template('admin_sorting.html', 
                          sorting_config=sorting_config,
                          manual_priority_str=manual_priority_str)

@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
def admin_settings():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        confirm_picking = request.form.get('confirm_picking_step', 'true')
        show_image = request.form.get('show_image_on_picking_screen', 'true')
        show_multi_qty_warning = request.form.get('show_multi_qty_warning', 'true')
        # Batch picking setting removed - will be rebuilt
        require_skip_reason = request.form.get('require_skip_reason', 'true')
        skip_reasons = request.form.get('skip_reasons', '')
        exception_reasons = request.form.get('exception_reasons', '')
        
        # Time tracking alert settings
        alerts_enabled = request.form.get('time_alerts_enabled', 'false') == 'true'
        warning_threshold = float(request.form.get('warning_threshold', '120'))
        critical_threshold = float(request.form.get('critical_threshold', '150'))
        auto_notify_admin = request.form.get('auto_notify_admin', 'false') == 'true'
        show_picker_warnings = request.form.get('show_picker_warnings', 'false') == 'true'
        
        # Helper function to save settings
        def save_setting(key, value):
            setting = Setting.query.filter_by(key=key).first()
            if setting:
                setting.value = value
            else:
                setting = Setting()
                setting.key = key
                setting.value = value
                db.session.add(setting)
        
        # Save time tracking alert settings
        from time_alerts import update_alert_settings
        alert_settings = {
            'enabled': alerts_enabled,
            'warning_threshold': warning_threshold,
            'critical_threshold': critical_threshold,
            'auto_notify_admin': auto_notify_admin,
            'show_picker_warnings': show_picker_warnings
        }
        update_alert_settings(alert_settings)
        
        # Save all settings
        save_setting('confirm_picking_step', confirm_picking)
        save_setting('show_image_on_picking_screen', show_image)
        save_setting('show_multi_qty_warning', show_multi_qty_warning)
        # Batch picking setting save removed - will be rebuilt
        save_setting('require_skip_reason', require_skip_reason)
        save_setting('skip_reasons', skip_reasons)
        save_setting('exception_reasons', exception_reasons)
        
        db.session.commit()
        flash('Settings updated successfully', 'success')
        return redirect(url_for('admin_settings'))
    
    # Get current settings
    confirm_picking = Setting.get(db.session, 'confirm_picking_step', 'true')
    show_image = Setting.get(db.session, 'show_image_on_picking_screen', 'true')
    show_multi_qty_warning = Setting.get(db.session, 'show_multi_qty_warning', 'true')
    # Batch picking setting removed - will be rebuilt
    require_skip_reason = Setting.get(db.session, 'require_skip_reason', 'true')
    
    # Get the skip reasons or provide defaults if not set
    default_skip_reasons = "Need assistance\nLocation not accessible\nNeed equipment\nNeed to check with supervisor\nOther"
    skip_reasons = Setting.get(db.session, 'skip_reasons', default_skip_reasons)
    
    # Get the exception reasons or provide defaults if not set
    default_exception_reasons = "Item not found\nInsufficient quantity\nDamaged product\nWrong location\nOther"
    exception_reasons = Setting.get(db.session, 'exception_reasons', default_exception_reasons)
    
    # Get current alert settings for display
    from time_alerts import get_alert_settings
    alert_settings = get_alert_settings()
    
    return render_template('admin_settings.html', 
                         confirm_picking=confirm_picking, 
                         show_image=show_image,
                         show_multi_qty_warning=show_multi_qty_warning,
                         # Batch picking template parameter removed - will be rebuilt
                         require_skip_reason=require_skip_reason,
                         skip_reasons=skip_reasons,
                         exception_reasons=exception_reasons,
                         alert_settings=alert_settings)

@app.route('/admin/time-alerts')
@login_required
def admin_time_alerts():
    """Admin dashboard for viewing and managing time tracking alerts"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    from time_alerts import get_active_alerts, get_alert_settings
    from models import TimeTrackingAlert
    
    # Get active alerts
    active_alerts = get_active_alerts()
    
    # Get resolved alerts from last 7 days
    from datetime import datetime, timedelta
    week_ago = datetime.now() - timedelta(days=7)
    resolved_alerts = TimeTrackingAlert.query.filter(
        TimeTrackingAlert.is_resolved == True,
        TimeTrackingAlert.resolved_at >= week_ago
    ).order_by(TimeTrackingAlert.resolved_at.desc()).limit(20).all()
    
    # Get alert settings
    alert_settings = get_alert_settings()
    
    return render_template('admin_time_alerts.html',
                         active_alerts=active_alerts,
                         resolved_alerts=resolved_alerts,
                         alert_settings=alert_settings)

@app.route('/admin/time-alerts/<int:alert_id>/resolve', methods=['POST'])
@login_required
def resolve_time_alert(alert_id):
    """Resolve a time tracking alert"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    from time_alerts import resolve_alert
    notes = request.form.get('notes', '')
    
    if resolve_alert(alert_id, current_user.username, notes):
        flash('Alert resolved successfully.', 'success')
    else:
        flash('Failed to resolve alert.', 'danger')
    
    return redirect(url_for('admin_time_alerts'))

@app.route('/admin/view_exceptions/<invoice_no>')
@login_required
def admin_view_exceptions(invoice_no):
    """View exceptions for a specific invoice"""
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get the invoice
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Get all exceptions for this invoice
    exceptions = PickingException.query.filter_by(invoice_no=invoice_no).order_by(PickingException.timestamp.desc()).all()
    
    # Get invoice items for reference
    items = InvoiceItem.query.filter_by(invoice_no=invoice_no).all()
    
    # Create a lookup dictionary for easier access to item details
    item_lookup = {item.item_code: item for item in items}
    
    return render_template('admin_view_exceptions.html', 
                          invoice=invoice, 
                          exceptions=exceptions,
                          item_lookup=item_lookup)

@app.route('/admin/corrections')
@login_required
def admin_corrections():
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get all users for the picker filter dropdown
    users = User.query.all()
    
    # Apply filters from request args
    invoice_filter = request.args.get('invoice_no', '')
    picker_filter = request.args.get('picker', '')
    status_filter = request.args.get('status', '')
    customer_filter = request.args.get('customer_name', '')
    
    # Start with all invoices
    query = Invoice.query
    
    # Apply filters
    if invoice_filter:
        query = query.filter(Invoice.invoice_no.like(f'%{invoice_filter}%'))
    
    if picker_filter:
        query = query.filter(Invoice.assigned_to == picker_filter)
    
    if status_filter:
        query = query.filter(Invoice.status == status_filter)
    
    if customer_filter:
        query = query.filter(Invoice.customer_name.like(f'%{customer_filter}%'))
    
    # Sort by invoice number descending
    query = query.order_by(Invoice.invoice_no.desc())
    
    # Get results
    invoices = query.all()
    
    return render_template('admin_corrections.html', 
                          invoices=invoices, 
                          users=users)

@app.route('/admin/invoice/<invoice_no>')
@login_required
def admin_view_invoice(invoice_no):
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get invoice and associated data
    invoice = Invoice.query.get_or_404(invoice_no)
    exceptions = PickingException.query.filter_by(invoice_no=invoice_no).all()
    
    # Apply custom sorting to the invoice items
    sorted_items = sort_items_by_config(invoice.items)
    
    # Import the helper function to get product images
    from utils.image_handler import get_product_image
    
    return render_template('admin_view_invoice.html', 
                          invoice=invoice, 
                          items=sorted_items,
                          exceptions=exceptions,
                          get_product_image=get_product_image)

@app.route('/admin/invoice/<invoice_no>/update', methods=['POST'])
@login_required
def admin_update_invoice_items(invoice_no):
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Process each item in the invoice
    for item in invoice.items:
        # Get form values for this item
        status = request.form.get(f'is_picked_{item.item_code}', 'not_picked')
        picked_qty = int(request.form.get(f'picked_qty_{item.item_code}', 0))
        
        # Update the item based on status
        if status == 'not_picked':
            item.is_picked = False
            item.picked_qty = None
            item.pick_status = 'not_picked'
        elif status == 'reset':
            item.is_picked = False
            item.picked_qty = None
            item.pick_status = 'reset'
            item.reset_by = current_user.username
            item.reset_timestamp = datetime.now()
            item.reset_note = "Reset by administrator"
        elif status == 'exception':
            item.is_picked = True
            item.picked_qty = picked_qty
            item.pick_status = 'exception'
        else:
            item.is_picked = True
            item.picked_qty = picked_qty
            item.pick_status = 'picked'
    
    # Recalculate invoice totals
    recalculate_invoice_totals(db.session, invoice_no)
    
    # Check if all items are picked and update the invoice status
    all_picked = all(item.is_picked for item in invoice.items)
    if all_picked and invoice.status != 'Completed':
        invoice.status = 'Completed'
    elif not all_picked and invoice.status == 'Completed':
        invoice.status = 'In Progress'
    
    db.session.commit()
    flash('Invoice items updated successfully', 'success')
    return redirect(url_for('admin_view_invoice', invoice_no=invoice_no))

@app.route('/admin/invoice/<invoice_no>/reset-progress')
@login_required
def admin_reset_invoice_progress(invoice_no):
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Reset all items
    for item in invoice.items:
        item.is_picked = False
        item.picked_qty = None
        item.pick_status = 'reset'
        item.reset_by = current_user.username
        item.reset_timestamp = datetime.now()
        item.reset_note = "Full invoice reset by administrator"
    
    # Reset invoice progress
    invoice.current_item_index = 0
    invoice.status = 'In Progress'
    
    # Recalculate invoice totals
    recalculate_invoice_totals(db.session, invoice_no)
    
    db.session.commit()
    flash('Invoice progress has been reset. All items are now marked as Not Picked.', 'success')
    return redirect(url_for('admin_view_invoice', invoice_no=invoice_no))

@app.route('/admin/invoice/<invoice_no>/item/<item_code>/reset')
@login_required
def admin_reset_item(invoice_no, item_code):
    # Only admin users can access this page
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Find the specific item
    item = None
    for i in invoice.items:
        if i.item_code == item_code:
            item = i
            break
    
    if not item:
        flash('Item not found', 'danger')
        return redirect(url_for('admin_view_invoice', invoice_no=invoice_no))
    
    # Reset the specific item
    item.is_picked = False
    item.picked_qty = None
    item.pick_status = 'reset'
    item.reset_by = current_user.username
    item.reset_timestamp = datetime.now()
    
    # Get reset note if provided
    reset_note = request.args.get('reset_note')
    if reset_note:
        item.reset_note = reset_note
    
    # Adjust invoice progress if needed
    # For in-progress invoices, we need to ensure they can pick this item again
    if invoice.status == 'In Progress':
        # Find the item's position in the list using custom sorting configuration
        items = sort_items_by_config(invoice.items)
        item_index = items.index(item)
        
        # If the current index is past this item, move it back
        if invoice.current_item_index > item_index:
            invoice.current_item_index = item_index
    
    # If the invoice was complete and we're un-picking an item, update status
    if invoice.status == 'Completed':
        invoice.status = 'In Progress'
    
    # Check if we need to update status based on picked items
    picked_items_count = sum(1 for item in invoice.items if item.is_picked)
    
    # Update status based on picked items count
    if picked_items_count == 0:
        # No items picked - set to "not_started"
        invoice.status = 'not_started'
        invoice.current_item_index = 0
    elif picked_items_count < len(invoice.items):
        # Some items picked but not all - set to "picking"
        invoice.status = 'picking'
    
    # Recalculate invoice totals
    recalculate_invoice_totals(db.session, invoice_no)
    
    # Add a note in the request form if provided
    note = request.args.get('reset_note')
    if note:
        # Could save to a notes table if needed
        pass
    
    db.session.commit()
    flash(f'Item {item_code} has been reset and is now available for picking again.', 'success')
    return redirect(url_for('admin_view_invoice', invoice_no=invoice_no))

# Picker routes
@app.route('/picker/dashboard')
@login_required
def picker_dashboard():
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    # Get all invoices assigned to this picker, excluding completed, delivered, and shipped orders
    invoices = Invoice.query.filter_by(assigned_to=current_user.username).filter(
        ~Invoice.status.in_(['ready_for_dispatch', 'shipped', 'delivered', 'delivery_failed', 'returned_to_warehouse', 'cancelled'])
    ).all()
    
    # Get batch picking sessions assigned to this picker (include today's completed ones)
    from datetime import date
    today = date.today()
    
    from sqlalchemy import or_, and_, func
    batch_sessions = BatchPickingSession.query.filter_by(
        assigned_to=current_user.username
    ).filter(
        or_(
            BatchPickingSession.status.in_(['Active', 'Paused']),
            and_(
                BatchPickingSession.status == 'Completed',
                func.date(BatchPickingSession.created_at) == today
            )
        )
    ).all()
    
    # Process batch sessions to include summary information
    batch_data = []
    for batch in batch_sessions:
        # Get invoices in this batch
        batch_invoices = BatchSessionInvoice.query.filter_by(batch_session_id=batch.id).all()
        invoice_count = len(batch_invoices)
        
        # Handle both active and completed batches
        if batch.status == 'Completed':
            # For completed batches, count items that were actually in the batch
            batch_zones = [zone.strip() for zone in batch.zones.split(',') if zone.strip()]
            batch_corridors = []
            if batch.corridors:
                batch_corridors = [corridor.strip() for corridor in batch.corridors.split(',') if corridor.strip()]
            
            total_items = 0
            completed_items = 0
            
            for bi in batch_invoices:
                invoice = Invoice.query.get(bi.invoice_no)
                if invoice:
                    items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
                    for item in items:
                        if item.zone in batch_zones:
                            if not batch_corridors or item.corridor in batch_corridors:
                                if item.locked_by_batch_id == batch.id:
                                    total_items += 1
                                    if item.is_picked:
                                        completed_items += 1
        else:
            # For active batches, use the filtered count method
            total_items = batch.get_filtered_item_count()
            completed_items = 0
            
            # Count completed items using the same filtering logic
            batch_zones = [zone.strip() for zone in batch.zones.split(',') if zone.strip()]
            batch_corridors = []
            if batch.corridors:
                batch_corridors = [corridor.strip() for corridor in batch.corridors.split(',') if corridor.strip()]
            
            for bi in batch_invoices:
                invoice = Invoice.query.get(bi.invoice_no)
                if invoice:
                    items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
                    
                    for item in items:
                        if item.zone in batch_zones:
                            if not batch_corridors or item.corridor in batch_corridors:
                                # Only count if item is available to this batch (not locked by others)
                                if item.locked_by_batch_id is None or item.locked_by_batch_id == batch.id:
                                    if item.is_picked:
                                        completed_items += 1
        
        batch_data.append({
            'session': batch,
            'invoice_count': invoice_count,
            'total_items': total_items,
            'completed_items': completed_items,
            'progress_percent': (completed_items / total_items * 100) if total_items > 0 else 0
        })
    
    # Sort batch data: completed batches last, then by creation date (newest first within each status)
    def batch_sort_key(batch_data):
        batch = batch_data['session']
        # Primary sort: status (completed batches last)
        status_priority = 0 if batch.status != 'Completed' else 1
        # Secondary sort: creation date (newest first)
        creation_date_priority = -batch.created_at.timestamp()
        return (status_priority, creation_date_priority)
    
    batch_data.sort(key=batch_sort_key)
    
    # Get active shift for this picker
    active_shift = get_active_shift(current_user.username)
    
    # Check if the picker is on break
    on_break = get_picker_on_break(current_user.username)
    
    # Record the activity for idle detection if user has an active shift
    if active_shift:
        record_activity(current_user.username, 'screen_interaction', 
                       details='Viewing picker dashboard')
    
    return render_template('picker_dashboard.html', 
                          invoices=invoices,
                          batch_sessions=batch_data,
                          active_shift=active_shift,
                          on_break=on_break,
                          now=datetime.now())

# Batch picking dashboard removed - will be rebuilt

@app.route('/picker/invoice/<invoice_no>/start')
@login_required
def start_picking(invoice_no):
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Verify this picker is assigned to this invoice
    if invoice.assigned_to != current_user.username:
        flash('You are not assigned to this invoice.', 'danger')
        return redirect(url_for('picker_dashboard'))
    
    # Update status to picking if not already
    if invoice.status == 'not_started':
        invoice.status = 'picking'
        invoice.current_item_index = 0
        
        # Log the actual start time for picking
        from models import ActivityLog
        start_log = ActivityLog(
            picker_username=current_user.username,
            activity_type='picking_started',
            invoice_no=invoice_no,
            details=f'Started picking order {invoice_no}'
        )
        db.session.add(start_log)
        db.session.commit()
    
    # Redirect to the picking page for the current item
    return redirect(url_for('pick_item', invoice_no=invoice_no))

@app.route('/picker/invoice/<invoice_no>/item', methods=['GET', 'POST'])
@login_required
def pick_item(invoice_no):
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Verify this picker is assigned to this invoice
    if invoice.assigned_to != current_user.username:
        flash('You are not assigned to this invoice.', 'danger')
        return redirect(url_for('picker_dashboard'))
    
    # Check for time tracking alerts before proceeding
    from time_alerts import check_order_time_alerts
    alert_info = check_order_time_alerts(invoice_no, current_user.username)
    
    # OPTIMIZED: Single query to get all items with lock status
    from sqlalchemy import text
    query = text("""
        SELECT ii.*, 
               CASE 
                   WHEN ii.locked_by_batch_id IS NOT NULL THEN 'batch_locked'
                   WHEN ii.is_picked = true THEN 'picked'
                   WHEN ii.pick_status = 'skipped_pending' THEN 'skipped_pending'
                   WHEN ii.pick_status = 'reset' THEN 'reset'
                   ELSE 'available'
               END as item_status,
               bps.name as lock_batch_name
        FROM invoice_items ii
        LEFT JOIN batch_picking_sessions bps ON ii.locked_by_batch_id = bps.id 
            AND bps.status IN ('Active', 'Paused')
        WHERE ii.invoice_no = :invoice_no
        ORDER BY 
            CASE 
                WHEN ii.pick_status = 'skipped_pending' THEN 2
                WHEN ii.is_picked = true THEN 3
                ELSE 1
            END,
            ii.zone, ii.corridor, ii.location
    """)
    
    result = db.session.execute(query, {'invoice_no': invoice_no})
    raw_items = result.fetchall()
    
    if not raw_items:
        flash('No items found for this invoice.', 'warning')
        return redirect(url_for('picker_dashboard'))
    
    # Convert to InvoiceItem objects and separate by status
    all_items = []
    items_to_pick = []
    locked_by_batches = []
    
    for row in raw_items:
        # Create InvoiceItem object from row
        item = InvoiceItem.query.filter_by(
            invoice_no=row.invoice_no, 
            item_code=row.item_code
        ).first()
        
        if item:
            all_items.append(item)
            
            # Check if item needs picking and isn't batch locked
            if row.item_status in ['available', 'reset', 'skipped_pending']:
                if row.item_status != 'batch_locked':
                    items_to_pick.append(item)
                else:
                    locked_by_batches.append(item)
    
    # Log locked items warning if any
    if locked_by_batches:
        current_app.logger.info(f"Blocked {len(locked_by_batches)} batch-locked items from regular picking in {invoice_no}")
    
    # If all remaining items are locked by batches, redirect to dashboard
    if len(locked_by_batches) > 0 and not items_to_pick:
        flash(f'All remaining items in this order are assigned to batch picking sessions and cannot be picked individually.', 'warning')
        return redirect(url_for('picker_dashboard'))
    
    # If all items are picked, check for skipped items that need resolution
    if not items_to_pick:
        # Mark any items not explicitly picked as skipped
        for item in all_items:
            if not item.is_picked and not item.pick_status:
                item.pick_status = 'skipped'
        
        # For completed invoices, set current_item_index to total_lines
        # This ensures progress indicators show 100% completion
        invoice.status = 'ready_for_dispatch'
        invoice.current_item_index = invoice.total_lines
        db.session.commit()
        flash('All items have been picked! Please proceed to the packing zone.', 'success')
        return redirect(url_for('ready_for_packing', invoice_no=invoice_no))
    
    # Check if there are only skipped_pending items left
    only_skipped_pending = all(item.pick_status == 'skipped_pending' for item in items_to_pick)
    if only_skipped_pending:
        flash('You have skipped items that need to be resolved before completing this order.', 'warning')
    
    # Apply custom sorting to items that need to be picked (already optimally sorted by the query)
    sorted_items_to_pick = items_to_pick
    
    # Sorting complete - items are now in proper sequence
    
    # For a POST request (item being picked)
    if request.method == 'POST':
        # Store the item code of the current item being picked to find it again after sorting
        try:
            current_item_code = request.form.get('item_code')
            if not current_item_code:
                # If no item code was provided, get it from the first unpicked item
                if sorted_items_to_pick:
                    current_item_code = sorted_items_to_pick[0].item_code
                else:
                    flash('No items left to pick', 'warning')
                    return redirect(url_for('picker_dashboard'))
                    
            # Find the item by its code
            current_item = next((item for item in sorted_items_to_pick if item.item_code == current_item_code), None)
            
            if not current_item:
                # Check if the item exists in the original list but was filtered out
                original_item = next((item for item in items_to_pick if item.item_code == current_item_code), None)
                if original_item:
                    # Item exists but was filtered out - check if it's locked by batch
                    from batch_locking_utils import check_item_lock_status
                    lock_status = check_item_lock_status(original_item.invoice_no, original_item.item_code)
                    if lock_status['locked']:
                        flash(f'Item {current_item_code} is locked by {lock_status["message"]}. This item must be picked through batch picking.', 'danger')
                        return redirect(url_for('picker_dashboard'))
                
                # Log the error for debugging
                current_app.logger.error(f"Item {current_item_code} not found in sorted list. Available items: {[item.item_code for item in sorted_items_to_pick]}")
                flash('Item not found or already picked', 'warning')
                return redirect(url_for('pick_item', invoice_no=invoice_no))
            
            # OPTIMIZED: Check if item is locked by batch (already filtered in main query)
            if current_item.locked_by_batch_id is not None:
                flash(f'Cannot pick item {current_item.item_code}: Item is locked by batch picking. This item must be picked through batch picking.', 'danger')
                return redirect(url_for('picker_dashboard'))
            
            # Check if the item is being skipped
            if request.form.get('skip') == 'true':
                # Process the skip action
                skip_reason = request.form.get('skip_reason', '')
                if skip_reason == 'Other':
                    other_reason = request.form.get('other_skip_reason', '')
                    if other_reason:
                        skip_reason = other_reason
                
                # Mark the item as skipped_pending
                current_item.pick_status = 'skipped_pending'
                current_item.skip_reason = skip_reason
                current_item.skip_timestamp = datetime.now()
                
                # Increment skip count - handle attribute error gracefully
                try:
                    if current_item.skip_count is None:
                        current_item.skip_count = 1
                    else:
                        current_item.skip_count += 1
                except (AttributeError, TypeError):
                    # If skip_count doesn't exist or has an unexpected type
                    current_item.skip_count = 1
                
                # Log the skip activity
                activity = ActivityLog()
                activity.picker_username = current_user.username
                activity.activity_type = 'item_skip'
                activity.invoice_no = invoice_no
                activity.item_code = current_item.item_code
                activity.details = f"Skipped item with reason: {skip_reason}"
                db.session.add(activity)
                
                # Save to the database
                db.session.commit()
                
                # Update order status with batch-aware logic
                from batch_aware_order_status import update_order_status_batch_aware
                status_summary = update_order_status_batch_aware(invoice_no)
                
                # Move this item to the end of the picking queue
                # We'll achieve this in GET request handling by prioritizing non-skipped items
                
                # Removed confirmation message as requested
                return redirect(url_for('pick_item', invoice_no=invoice_no))
                
            # Process the pick
            picked_qty = int(request.form.get('picked_qty', current_item.qty))
            confirm = request.form.get('confirm') == 'true'
            
            # Validate picked quantity
            if picked_qty > current_item.qty:
                flash('Error: Picked quantity cannot exceed requested quantity', 'danger')
                return redirect(url_for('pick_item', invoice_no=invoice_no))
            
            if confirm:
                # Complete per-product time tracking
                tracking_id = request.form.get('tracking_id')
                if tracking_id:
                    from item_tracking import complete_item_tracking
                    picked_correctly = picked_qty == current_item.qty
                    complete_item_tracking(
                        tracking_id=int(tracking_id),
                        picked_qty=picked_qty,
                        picked_correctly=picked_correctly,
                        was_skipped=False
                    )
                
                # Mark the item as picked
                current_item.is_picked = True
                current_item.picked_qty = picked_qty
                
                # Update the pick status
                if picked_qty == current_item.qty:
                    current_item.pick_status = 'picked'
                else:
                    current_item.pick_status = 'exception'
                
                # Log an exception if quantities don't match
                if picked_qty != current_item.qty:
                    exception = PickingException()
                    exception.invoice_no = invoice_no
                    exception.item_code = current_item.item_code
                    exception.expected_qty = current_item.qty
                    exception.picked_qty = picked_qty
                    exception.picker_username = current_user.username
                    exception.reason = request.form.get('reason')
                    db.session.add(exception)
                
                # Save to the database
                db.session.commit()
                
                # Update order status with batch-aware logic
                from batch_aware_order_status import update_order_status_batch_aware
                status_summary = update_order_status_batch_aware(invoice_no)
                
                # Refresh the list of items to pick
                items_to_pick = [item for item in all_items 
                                if not item.is_picked or item.pick_status == 'reset']
                sorted_items_to_pick = sort_items_by_config(items_to_pick)
                
                # If there are more items to pick, continue
                if sorted_items_to_pick:
                    return redirect(url_for('pick_item', invoice_no=invoice_no))
                else:
                    # Record picking completion time but keep status as picking until packing is done
                    from timezone_utils import get_local_time
                    invoice.picking_complete_time = get_local_time()
                    invoice.current_item_index = invoice.total_lines
                    db.session.commit()
                    flash('All items have been picked! Please proceed to the packing zone.', 'success')
                    return redirect(url_for('ready_for_packing', invoice_no=invoice_no))
                    
        except ValueError:
            flash('Invalid quantity value', 'danger')
            return redirect(url_for('pick_item', invoice_no=invoice_no))
    
    # For a GET request (showing the next item to pick)
    # Always pick the first unpicked item from the sorted list
    if not sorted_items_to_pick:
        flash('No items left to pick for this invoice.', 'warning')
        return redirect(url_for('picker_dashboard'))
        
    # Get the first item in the sorted unpicked items list
    current_item = sorted_items_to_pick[0]
    
    # Check if this is a skipped item being resolved
    is_skipped_resolution = current_item.pick_status == 'skipped_pending'
    
    # Parse the location into components for display
    # For format "10-05-A01": corridor-aisle-levelbin
    location_parts = {'aisle': '', 'shelf': '', 'level': '', 'bin': ''}
    if current_item.location:
        parts = current_item.location.strip().split('-')
        if len(parts) >= 1:
            location_parts['aisle'] = parts[0]  # corridor (10)
        if len(parts) >= 2:
            location_parts['shelf'] = parts[1]  # aisle/shelf (05)
        if len(parts) >= 3:
            # Parse level and bin from "A01" -> level "A", bin "01"
            level_bin = parts[2]
            import re
            match = re.match(r'([A-Za-z]*)(\d*)', level_bin)
            if match:
                level_part, bin_part = match.groups()
                location_parts['level'] = level_part  # A
                location_parts['bin'] = bin_part      # 01
    
    # Check if there's a next item after the CURRENT item and get its location
    # This shows a preview of the next location that will be picked (after the current one)
    next_item_location = None
    
    # CRITICAL FIX: Always show the next item in the list as preview
    # We only want to show location for items with index 1+ (not the first item)
    if len(sorted_items_to_pick) > 1:
        next_item = sorted_items_to_pick[1]  # Always show the second item in the list
        if next_item and next_item.location:
            next_item_location = next_item.location
    
    # Get product image for confirmation screen
    product_image = get_product_image(current_item.item_code)
    
    # Get configuration settings
    confirm_picking = Setting.get(db.session, 'confirm_picking_step', 'true')
    show_image = Setting.get(db.session, 'show_image_on_picking_screen', 'true')
    require_skip_reason = Setting.get(db.session, 'require_skip_reason', 'true')
    
    # Get skip reasons list
    default_skip_reasons = "Need assistance\nLocation not accessible\nNeed equipment\nNeed to check with supervisor"
    skip_reasons = Setting.get(db.session, 'skip_reasons', default_skip_reasons)
    skip_reasons_list = [reason.strip() for reason in skip_reasons.splitlines() if reason.strip()]
    
    # Calculate picked items count for progress display
    picked_items_count = len([item for item in all_items if item.is_picked])
    total_items_count = len(all_items)
    
    # Start per-product time tracking for AI analysis
    tracking_id = None
    try:
        from item_tracking import start_item_tracking
        
        # Get previous location for distance calculation
        previous_location = None
        if picked_items_count > 0:
            last_picked = [item for item in all_items if item.is_picked]
            if last_picked:
                previous_location = last_picked[-1].location
        
        tracking = start_item_tracking(
            invoice_no=invoice_no,
            item_code=current_item.item_code,
            picker_username=current_user.username,
            previous_location=previous_location
        )
        
        if tracking:
            tracking_id = tracking.id
    except Exception as e:
        print(f"Error starting item tracking: {e}")
    
    # Get the multi-quantity warning setting
    show_multi_qty_warning = Setting.get(db.session, 'show_multi_qty_warning', 'true')
    
    # Get exception reasons for the issue modal
    default_exception_reasons = "Item not found\nInsufficient quantity\nDamaged product\nWrong location\nOther"
    exception_reasons_text = Setting.get(db.session, 'exception_reasons', default_exception_reasons)
    exception_reasons_list = [reason.strip() for reason in exception_reasons_text.split('\n') if reason.strip()]
    
    return render_template('picking.html', 
                          invoice=invoice, 
                          item=current_item, 
                          location_parts=location_parts, 
                          current_index=invoice.current_item_index + 1, 
                          remaining_items=len(sorted_items_to_pick),
                          picked_items=picked_items_count,
                          total_items=total_items_count,
                          product_image=product_image,
                          confirm_picking=confirm_picking,
                          show_image=show_image,
                          next_item_location=next_item_location,
                          require_skip_reason=require_skip_reason,
                          skip_reasons_list=skip_reasons_list,
                          exception_reasons_list=exception_reasons_list,
                          is_reset_item=current_item.pick_status == 'reset',
                          is_skipped_resolution=is_skipped_resolution,
                          skip_reason=current_item.skip_reason if is_skipped_resolution else None,
                          tracking_id=tracking_id,
                          show_multi_qty_warning=show_multi_qty_warning)

@app.route('/picker/invoice/<invoice_no>/completed')
@login_required
def picking_completed(invoice_no):
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Verify this picker is assigned to this invoice
    if invoice.assigned_to != current_user.username:
        flash('You are not assigned to this invoice.', 'danger')
        return redirect(url_for('picker_dashboard'))
    
    # Check if there were any exceptions during picking
    exceptions = PickingException.query.filter_by(invoice_no=invoice_no).all()
    
    return render_template('picking_completed.html', invoice=invoice, exceptions=exceptions)

@app.route('/admin/invoice/<invoice_no>/print')
@login_required
def print_invoice(invoice_no):
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Check access permissions
    if current_user.role != 'admin' and current_user.username != invoice.assigned_to:
        flash('Access denied. Only admin or the assigned picker can print this invoice.', 'danger')
        return redirect(url_for('index'))
    
    # Check if this was called from the packing confirmation screen
    return_to_packing = request.args.get('from_packing') == 'true'
    
    # Admin can print invoices in any status
    
    # Get all items for this invoice, sorted using the same logic as picker interface
    all_items = InvoiceItem.query.filter_by(invoice_no=invoice_no).all()
    all_items = sort_items_by_config(all_items)
    
    # Get any exceptions for this invoice
    exceptions = PickingException.query.filter_by(invoice_no=invoice_no).all()
    
    # Get batch-picked items for this invoice
    from models import BatchPickedItem, BatchPickingSession
    batch_items = []
    batch_info = {}
    batch_item_codes = set()  # To track which items were batch-picked
    
    # Query for batch-picked items
    batch_picked_records = BatchPickedItem.query.filter_by(invoice_no=invoice_no).all()
    
    if batch_picked_records:
        for record in batch_picked_records:
            # Get the original invoice item for details
            item = InvoiceItem.query.filter_by(
                invoice_no=invoice_no, 
                item_code=record.item_code
            ).first()
            
            if item:
                # Add item code to the tracking set
                batch_item_codes.add(item.item_code)
                
                # Get batch session details
                if record.batch_session_id not in batch_info:
                    batch = BatchPickingSession.query.get(record.batch_session_id)
                    batch_info[str(record.batch_session_id)] = {
                        'id': record.batch_session_id,
                        'name': batch.name if batch else f"Batch #{record.batch_session_id}",
                        'batch_number': batch.batch_number if batch and batch.batch_number else f"BATCH-{record.batch_session_id}"
                    }
                
                # Create batch item entry with all necessary fields
                batch_items.append({
                    'item_code': item.item_code,
                    'item_name': item.item_name,
                    'location': item.location,
                    'unit_type': item.unit_type,
                    'pack': item.pack,
                    'batch_id': record.batch_session_id,
                    'batch_name': batch_info[str(record.batch_session_id)]['name'],
                    'qty': record.picked_qty,
                    'requested_qty': item.qty
                })
    
    # Mark items as batch-picked or not
    for item in all_items:
        if item.item_code in batch_item_codes:
            item.batch_id = True  # Mark as batch-picked
    
    # Process manually picked items (those that weren't batch-picked)
    manually_picked = [item for item in all_items if item.item_code not in batch_item_codes]
    
    # Count statistics
    total_item_count = len(all_items)
    manual_count = len(manually_picked)
    batch_count = len(batch_items)
    
    # Choose the appropriate template based on the order status and user role
    if invoice.status == 'Ready for Packing' or (current_user.role == 'picker' and invoice.status == 'In Progress'):
        # Use the picking report template for packing preparation
        return render_template('print_picking_report.html', 
                             invoice=invoice, 
                             items=all_items,         # All items with batch_id flag
                             manually_picked=manually_picked,  # Only manually picked items
                             exceptions=exceptions,
                             batch_items=batch_items,
                             batch_info=batch_info,
                             total_count=total_item_count,
                             manual_count=manual_count,
                             batch_count=batch_count,
                             current_user=current_user,
                             return_to_packing=return_to_packing,
                             now=datetime.now())
    else:
        # Use the shipping label template for completed orders
        return render_template('print_invoice.html', 
                             invoice=invoice, 
                             items=all_items,
                             manually_picked=manually_picked,
                             exceptions=exceptions,
                             batch_items=batch_items,
                             batch_info=batch_info,
                             return_to_packing=return_to_packing,
                             total_count=total_item_count,
                             manual_count=manual_count,
                             batch_count=batch_count)

@app.route('/admin/time_analysis')
@login_required
def time_analysis_dashboard():
    """Time analysis dashboard showing walking, picking, and packing time breakdown"""
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('index'))
    
    # Get completed orders with time data
    completed_orders = Invoice.query.filter_by(status='Completed').order_by(Invoice.packing_complete_time.desc()).limit(20).all()
    
    # Simple time analysis
    order_analytics = []
    for invoice in completed_orders:
        items = InvoiceItem.query.filter_by(invoice_no=invoice.invoice_no).all()
        total_expected_time = sum(item.exp_time or 0 for item in items)
        unique_locations = len(set(item.location for item in items if item.location))
        
        # Estimate time breakdown (walking 30%, picking 60%, packing 10%)
        estimated_walking = total_expected_time * 0.3
        estimated_picking = total_expected_time * 0.6
        estimated_packing = total_expected_time * 0.1
        
        order_analytics.append({
            'invoice': invoice,
            'total_items': len(items),
            'unique_locations': unique_locations,
            'walking_time': estimated_walking,
            'picking_time': estimated_picking,
            'packing_time': estimated_packing,
            'total_time': total_expected_time
        })
    
    # Calculate summary stats
    total_walking = sum(order['walking_time'] for order in order_analytics)
    total_picking = sum(order['picking_time'] for order in order_analytics)
    total_packing = sum(order['packing_time'] for order in order_analytics)
    total_time = total_walking + total_picking + total_packing
    
    summary_stats = {
        'total_orders': len(order_analytics),
        'avg_walking_time': round(total_walking / max(len(order_analytics), 1), 1),
        'avg_picking_time': round(total_picking / max(len(order_analytics), 1), 1),
        'avg_packing_time': round(total_packing / max(len(order_analytics), 1), 1),
        'walking_percentage': round((total_walking / max(total_time, 1)) * 100, 1),
        'picking_percentage': round((total_picking / max(total_time, 1)) * 100, 1),
        'packing_percentage': round((total_packing / max(total_time, 1)) * 100, 1)
    }
    
    return render_template('time_analysis_simple.html', 
                         order_analytics=order_analytics,
                         summary_stats=summary_stats)

# Batch Picking - Create Session
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Manage Sessions
# Batch picking route handler removed - will be rebuilt

# Batch Picking - View Session Details
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Assign to Picker
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Delete Session
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Start Session (for pickers)
# Batch picking route handler removed - will be rebuilt

# Batch picking route handler removed - will be rebuilt
# Batch picking function removed - will be rebuilt
    
# Batch picking function removed - will be rebuilt

# Batch Picking - Pick Items
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Completed
# Batch picking route handler removed - will be rebuilt

# Batch Picking - Print Report
# Batch picking route handler removed - will be rebuilt

# Ready for Packing Screen
@app.route('/picker/invoice/<invoice_no>/ready-for-packing')
@login_required
def ready_for_packing(invoice_no):
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Verify this picker is assigned to this invoice
    if invoice.assigned_to != current_user.username:
        flash('You are not assigned to this invoice.', 'danger')
        return redirect(url_for('picker_dashboard'))
    
    # Check for skipped items that need resolution
    skipped_items = InvoiceItem.query.filter_by(
        invoice_no=invoice_no, 
        pick_status='skipped_pending'
    ).all()
    
    if skipped_items:
        # There are skipped items that need resolution
        flash('You have skipped items that need to be resolved before packing. Please complete picking all items.', 'warning')
        return redirect(url_for('pick_item', invoice_no=invoice_no))
    
    # Get all exceptions for this invoice
    exceptions = PickingException.query.filter_by(invoice_no=invoice_no).all()
    
    return render_template('ready_for_packing.html', invoice=invoice, exceptions=exceptions, now=datetime.now())

# Mark Packing as Complete
@app.route('/picker/invoice/<invoice_no>/mark-as-packed', methods=['POST'])
@login_required
def mark_as_packed(invoice_no):
    if current_user.role != 'picker':
        flash('Access denied. Picker privileges required.', 'danger')
        return redirect(url_for('index'))
    
    invoice = Invoice.query.get_or_404(invoice_no)
    
    # Verify this picker is assigned to this invoice
    if invoice.assigned_to != current_user.username:
        flash('You are not assigned to this invoice.', 'danger')
        return redirect(url_for('picker_dashboard'))
        
    # Double check for skipped items that need resolution
    skipped_items = InvoiceItem.query.filter_by(
        invoice_no=invoice_no, 
        pick_status='skipped_pending'
    ).all()
    
    if skipped_items:
        # There are skipped items that need resolution
        flash('You have skipped items that need to be resolved before packing. Please complete picking all items.', 'warning')
        return redirect(url_for('pick_item', invoice_no=invoice_no))
    
    # Update the invoice status to ready_for_dispatch and record packing time
    from timezone_utils import get_local_time
    invoice.status = 'ready_for_dispatch'
    invoice.packing_complete_time = get_local_time()
    
    # Log the actual completion time for accurate time tracking
    from models import ActivityLog
    completion_log = ActivityLog(
        picker_username=current_user.username,
        activity_type='picking_completed',
        invoice_no=invoice_no,
        details=f'Completed order {invoice_no}'
    )
    db.session.add(completion_log)
    db.session.commit()
    
    flash('Order has been marked as packed and completed successfully.', 'success')
    return redirect(url_for('picking_completed', invoice_no=invoice_no))

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, error_message='Page not found'), 404

@app.errorhandler(403)
def forbidden(e):
    return render_template('403.html'), 403

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error_code=500, error_message='Server error'), 500
@app.route('/admin/update-routing-number', methods=['POST'])
@login_required
def update_routing_number():
    """Update the routing number for an invoice"""
    try:
        data = request.get_json()
        invoice_no = data.get('invoice_no')
        routing_number = data.get('routing_number')
        
        if not invoice_no:
            return jsonify({'success': False, 'error': 'Invoice number is required'})
        
        # Find the invoice
        invoice = Invoice.query.filter_by(invoice_no=invoice_no).first()
        if not invoice:
            return jsonify({'success': False, 'error': 'Invoice not found'})
        
        # Update the routing number (convert empty string to None)
        invoice.routing = routing_number if routing_number.strip() else None
        
        # Log the activity
        activity_log = ActivityLog(
            invoice_no=invoice_no,
            activity_type='admin_correction',
            details=f'Routing number updated to: {routing_number or "None"} by {current_user.username}',
            picker_username=current_user.username,
            timestamp=get_local_time()
        )
        db.session.add(activity_log)
        
        # Commit the changes
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Routing number updated successfully'})
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error updating routing number: {str(e)}")
        return jsonify({'success': False, 'error': 'Failed to update routing number'})
    
@app.route('/admin/quick-view-breakdown', methods=['POST'])
@login_required
def quick_view_breakdown():
    if current_user.role != 'admin':
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    invoice_nos = data.get('invoice_nos', [])
    
    if not invoice_nos:
        return jsonify({'error': 'No orders selected'}), 400
    
    # Get order details
    orders = Invoice.query.filter(Invoice.invoice_no.in_(invoice_nos)).all()
    
    # Get items for all selected orders
    items = InvoiceItem.query.filter(InvoiceItem.invoice_no.in_(invoice_nos)).all()
    
    # Calculate unit type breakdown
    unit_counts = {}
    total_items = 0
    case_items = []  # Collect all case items for detailed review
    
    for item in items:
        unit_type = item.unit_type or 'Unknown'
        quantity = item.qty or 0
        
        if unit_type not in unit_counts:
            unit_counts[unit_type] = 0
        unit_counts[unit_type] += quantity
        total_items += quantity
        
        # Collect case items for detailed review
        if unit_type.lower() in ['case', 'cases', 'cs', 'cse']:
            case_items.append({
                'invoice_no': item.invoice_no,
                'item_code': item.item_code,
                'item_name': item.item_name or 'Unknown Item',
                'quantity': quantity,
                'unit_type': unit_type,
                'location': item.location or 'Not specified'
            })
    
    # Calculate percentages and format breakdown
    unit_breakdown = []
    for unit_type, count in sorted(unit_counts.items()):
        percentage = round((count / total_items * 100), 1) if total_items > 0 else 0
        unit_breakdown.append({
            'unit_type': unit_type,
            'quantity': count,
            'percentage': percentage
        })
    
    # Calculate summary
    total_weight = sum(order.total_weight or 0 for order in orders)
    total_time = sum(order.total_exp_time or 0 for order in orders)
    
    # Format order details
    order_details = []
    for order in orders:
        order_details.append({
            'invoice_no': order.invoice_no,
            'customer_name': order.customer_name or 'Unknown',
            'total_items': order.total_items or 0,
            'total_weight': round(order.total_weight or 0, 1)
        })
    
    response_data = {
        'summary': {
            'total_orders': len(orders),
            'total_items': total_items,
            'total_weight': round(total_weight, 1),
            'total_time': round(total_time, 1),
            'total_cases': len(case_items)
        },
        'unit_breakdown': unit_breakdown,
        'case_items': case_items,
        'orders': order_details
    }
    
    return jsonify(response_data)

# Import shift tracking routes
from routes_shifts import *
