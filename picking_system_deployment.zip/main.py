import os
os.environ['TZ'] = 'Europe/Athens'

from app import app
import routes  # noqa: F401
import routes_ai_analysis  # noqa: F401
import routes_operations  # noqa: F401
import routes_daily_reports  # noqa: F401
import pytz
from datetime import datetime

# Apply performance optimizations
app.config.update({
    'DEBUG': False,
    'SESSION_COOKIE_HTTPONLY': True,
    'PERMANENT_SESSION_LIFETIME': 3600,
    'JSON_SORT_KEYS': False,
    'JSONIFY_PRETTYPRINT_REGULAR': False,
    'SQLALCHEMY_ENGINE_OPTIONS': {
        'pool_size': 20,
        'max_overflow': 30,
        'pool_pre_ping': True,
        'pool_recycle': 300,
        'echo': False,
        'pool_timeout': 20,
        'connect_args': {
            'connect_timeout': 10,
            'application_name': 'picking_system_optimized'
        }
    }
})

# Add template filter for timezone conversion
@app.template_filter('local_time')
def local_time_filter(dt, format_str='%d/%m/%y %H:%M'):
    """Display datetime in Athens timezone"""
    if dt is None:
        return 'N/A'
    
    athens_tz = pytz.timezone('Europe/Athens')
    
    # Database stores times in UTC, so we need to add 3 hours for Athens time
    if dt.tzinfo is None:
        # Add timezone info as UTC first, then convert to Athens
        utc_dt = pytz.UTC.localize(dt)
        athens_dt = utc_dt.astimezone(athens_tz)
        return athens_dt.strftime(format_str)
    
    # If datetime already has timezone info, convert to Athens time
    athens_dt = dt.astimezone(athens_tz)
    return athens_dt.strftime(format_str)

# Add current time filter for real-time display
@app.template_filter('current_athens_time')
def current_athens_time_filter(format_str='%d/%m/%y %H:%M:%S'):
    """Get current time in Athens timezone"""
    athens_tz = pytz.timezone('Europe/Athens')
    utc_now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    athens_now = utc_now.astimezone(athens_tz)
    return athens_now.strftime(format_str)

# Add template filter for status display
@app.template_filter('status_badge')
def status_badge_filter(status_value):
    """Display status as a styled badge"""
    from order_status_constants import get_status_info, get_status_badge_class, get_status_icon
    
    status_info = get_status_info(status_value)
    if not status_info:
        return f'<span class="badge bg-secondary">Unknown Status</span>'
    
    badge_class = get_status_badge_class(status_value)
    icon = get_status_icon(status_value)
    label = status_info['label']
    
    return f'<span class="badge {badge_class}"><i class="{icon} me-1"></i>{label}</span>'
from update_schema_skipped_items import update_database_schema
import logging
from routes_batch import batch_bp
from routes_shipments import shipments_bp
from routes_help import help_bp

logging.basicConfig(level=logging.INFO)

# Register the batch picking blueprint
app.register_blueprint(batch_bp, url_prefix='')

# Register the shipment management blueprint
app.register_blueprint(shipments_bp, url_prefix='')

# Register the help documentation blueprint
app.register_blueprint(help_bp, url_prefix='')

# Update schema
with app.app_context():
    # Update schema for skip and collect functionality
    try:
        update_database_schema()
    except Exception as e:
        logging.error(f"Error updating skip schema: {str(e)}")
    
    # Update schema for batch picking
    try:
        from update_batch_picking_schema import update_database_schema as update_batch_schema
        update_batch_schema()
    except Exception as e:
        logging.error(f"Error updating batch schema: {str(e)}")
        
    # Update schema to add batch_number field
    try:
        from update_batch_number_schema import update_database_schema as update_batch_number_schema
        update_batch_number_schema()
        logging.info("Batch number schema updates completed")
    except Exception as e:
        logging.error(f"Error updating batch number schema: {str(e)}")
        
    # Update schema for item time tracking AI features
    try:
        from update_item_tracking_schema import update_item_tracking_schema
        update_item_tracking_schema()
        logging.info("Item tracking schema updates completed")
    except Exception as e:
        logging.error(f"Error updating item tracking schema: {str(e)}")
    
    # Update invoice status timestamp schema
    try:
        from update_invoice_status_timestamp import add_status_timestamp_column
        add_status_timestamp_column()
        logging.info("Invoice status timestamp schema updates completed")
    except Exception as e:
        logging.error(f"Error updating invoice status timestamp schema: {str(e)}")
    
    # Initialize remaining tables
    from app import db
    db.create_all()
    
    # Update to new order status system
    try:
        from update_order_status_system import update_order_status_system
        update_order_status_system()
        logging.info("Order status system migration completed")
    except Exception as e:
        logging.error(f"Error updating order status system: {str(e)}")
    
    # Initialize settings if they don't exist
    try:
        from models import Setting
        # Check if skip_reasons setting exists
        skip_reasons = db.session.query(Setting).filter_by(key='skip_reasons').first()
        if not skip_reasons:
            # Create default skip reasons
            import json
            default_reasons = ["Out of Stock", "Damaged", "Location Empty", "Other"]
            new_setting = Setting(key='skip_reasons', value=json.dumps(default_reasons))
            db.session.add(new_setting)
            db.session.commit()
            logging.info("Default skip reasons initialized")
    except Exception as e:
        logging.error(f"Error initializing settings: {str(e)}")
        db.session.rollback()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
