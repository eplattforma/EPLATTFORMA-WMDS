# Emergency Performance Configuration - Reduced Load
import os

# Server socket - ultra minimal settings
bind = "0.0.0.0:5000"
backlog = 64

# Ultra minimal configuration for load reduction
workers = 1
worker_class = "sync" 
worker_connections = 10
max_requests = 25
max_requests_jitter = 5

# Ultra aggressive timeouts
timeout = 8
keepalive = 0
graceful_timeout = 5

# Minimal logging for performance
loglevel = "error"
accesslog = None
errorlog = "/tmp/gunicorn_error.log"

# Performance settings
preload_app = True
reuse_port = True
worker_tmp_dir = "/dev/shm"

print("Emergency config: 2 workers, minimal resources")