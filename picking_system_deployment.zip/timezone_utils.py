"""
Timezone utility functions for the warehouse picking system
"""
import pytz
from datetime import datetime
from models import Setting
from app import db

def get_system_timezone():
    """Get the configured system timezone, defaults to Europe/Athens"""
    try:
        timezone_str = Setting.get(db.session, 'system_timezone', 'Europe/Athens')
        return pytz.timezone(timezone_str)
    except Exception:
        return pytz.timezone('Europe/Athens')

def get_local_time():
    """Get current time in the configured timezone"""
    tz = get_system_timezone()
    utc_now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    return utc_now.astimezone(tz)

def get_utc_now():
    """Get current UTC time for database storage"""
    return datetime.utcnow()

def get_local_now():
    """Get current time in local timezone for display and operations"""
    return get_local_time().replace(tzinfo=None)

def format_local_time(dt=None, format_str='%Y-%m-%d %H:%M:%S'):
    """Format datetime in local timezone"""
    if dt is None:
        dt = get_local_time()
    elif dt.tzinfo is None:
        # Assume UTC if no timezone info
        dt = pytz.UTC.localize(dt)
        dt = dt.astimezone(get_system_timezone())
    
    return dt.strftime(format_str)

def localize_datetime(dt):
    """Convert a UTC datetime to local timezone"""
    if dt is None:
        return None
    
    if dt.tzinfo is None:
        # Assume UTC if no timezone info
        dt = pytz.UTC.localize(dt)
    
    return dt.astimezone(get_system_timezone())